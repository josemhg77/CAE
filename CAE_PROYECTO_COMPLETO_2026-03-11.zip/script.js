// LOOP CAD 2026 - Multi-sheet, full DXF export
document.addEventListener('DOMContentLoaded', () => {
    init();
});

const canvas = document.getElementById('loopCanvas');
const ctx = canvas.getContext('2d');

const CONFIG = {
    canvasWidth: 1800,
    canvasHeight: 4800, // Increased to accommodate 350px rows (12 loops)
    colors: {
        bg: '#1a1a1a',
        text: '#ffffff',
        line: '#ffffff',
        cable: '#ffffff',
        wireText: '#ffffff',
        shield: '#cccccc',
        grid: '#333333'
    },
    fonts: {
        header: 'bold 20px "Consolas", monospace',
        subHeader: 'bold 16px "Consolas", monospace',
        tag: 'bold 18px "Consolas", monospace',
        label: '16px "Consolas", monospace',
        small: '14px "Consolas", monospace',
        mono: '14px "Consolas", monospace',
        wire: 'bold 11px Arial',
        cableTag: 'bold 14px Arial'
    }
};

// ── Multi-sheet state ──────────────────────────────────────────────────────────
let sheets = [];          // sheets[sheetIdx] = array of 12 loops
let currentSheetIndex = 0;
let currentLoopIndex = 0;
let cableNamingMode = 'TAG';
let projectName = '';
let canvasScale = 1.0;
let isUserLoggedIn = false; // v2.1.5: Security access control
let loggedInUser = '';      // Nombre del usuario activo

let duplicateTags = new Set();
let duplicateCables = new Set();

function getCurrentLoops() { return sheets[currentSheetIndex]; }

function createEmptyLoop(id) {
    const loopNum = id + 1;
    const tag = `LT-${100 + id}`;
    const tms = [];
    // Generate pairing pattern labels for default terminals: 1+, 1-, 2+, 2-, etc.
    tms.push(`${loopNum}+`);
    tms.push(`${loopNum}-`);
    for (let i = 3; i <= 8; i++) tms.push(`${loopNum}.${i}`);

    return {
        id,
        instTag: tag,
        instType: 'Nivel',
        instTerms: ['+', '-', '3', '4', '5', '6', '7', '8'],
        instCategory: 'STD', // STD, 3W, VALVE, MOTOR
        instHilos: ['', '', '', '', '', '', '', ''],
        signalNames: ['SIG1', 'SIG2', 'SIG3', 'SIG4'],

        cable1Tag: `W${tag}`,
        cable1Section: '2x1.0mm²',
        cable1Shield: true,
        cable1Armor: false,
        cable1Len: 0,

        jbEnabled: true,
        marshEnabled: true,

        jbTag: 'JB-1',
        jbModule: 'JX1',
        jbMaxTerms: 48,
        jbTerms: [...tms],
        jbTermSh: 'PE',
        jbHilos: { inPos: '', outPos: '', inNeg: '', outNeg: '', inSh: '', outSh: '' },

        cable2Tag: `JB-1`,
        cable2Section: '12x1.0mm²',
        cable2Shield: true,
        cable2Armor: true,
        cable2Len: 0,

        marshTag: 'BME-101',
        marshTerms: [...tms],
        marshTermInSh: 'PE',
        marshModule: 'X12',
        marshMaxTerms: 48,
        marshHilos: { inPos: '', outPos: '', inNeg: '', outNeg: '', inSh: '', outSh: '' },

        cableSysTag: 'W-SYS',
        cableSysSection: '2x0.5mm²',
        cableSysShield: true,
        cableSysArmor: false,
        cableSysLen: 0,

        plcTag: 'SCP',
        plcModule: 'X1',
        plcTerms: ['1', '2', '3', '4', '5', '6', '7', '8'],
        plcTermPe: 'PE',
        plcHilos: { h1: '', h2: '', h3: '', h4: '', h5: '', h6: '', h7: '', h8: '', hPe: '' },
        plcDetails: `Señal: ${tag}`
    };
}

function createBlankLoop(id) {
    return {
        id,
        instTag: '', instType: 'Nivel', instTerms: ['', '', '', '', '', '', '', ''], instCategory: 'STD',
        instHilos: ['', '', '', '', '', '', '', ''],
        signalNames: ['', '', '', ''],
        cable1Tag: '', cable1Section: '', cable1Shield: false, cable1Armor: false, cable1Len: 0,
        jbEnabled: false, marshEnabled: false,
        jbTag: '', jbModule: '', jbMaxTerms: 48, jbTerms: ['', '', '', '', '', '', '', ''], jbTermSh: '',
        jbHilos: { inPos: '', outPos: '', inNeg: '', outNeg: '', inSh: '', outSh: '' },
        cable2Tag: '', cable2Section: '', cable2Shield: false, cable2Armor: false, cable2Len: 0,
        marshTag: '', marshTerms: ['', '', '', '', '', '', '', ''], marshTermInSh: '', marshModule: '', marshMaxTerms: 48,
        marshHilos: { inPos: '', outPos: '', inNeg: '', outNeg: '', inSh: '', outSh: '' },
        cableSysTag: '', cableSysSection: '', cableSysShield: false, cableSysArmor: false, cableSysLen: 0,
        plcTag: '', plcModule: '', plcTerms: ['', '', '', '', '', '', '', ''], plcTermPe: '',
        plcHilos: { h1: '', h2: '', h3: '', h4: '', h5: '', h6: '', h7: '', h8: '', hPe: '' },
        plcDetails: ''
    };
}

function createEmptySheet() {
    const s = [];
    for (let i = 0; i < 12; i++) s.push(createEmptyLoop(i)); // Default populated loops
    return s;
}

function createBlankSheet() {
    const s = [];
    for (let i = 0; i < 12; i++) s.push(createBlankLoop(i)); // Truly empty loops
    return s;
}

// ── Init ───────────────────────────────────────────────────────────────────────
function init() {
    canvas.width = CONFIG.canvasWidth;
    canvas.height = CONFIG.canvasHeight;

    const savedData = localStorage.getItem('loopCAD_autosave');
    if (savedData) {
        try {
            const d = JSON.parse(savedData);
            if (d.sheets) {
                sheets = d.sheets;
            } else if (d.loops) {
                sheets = [d.loops];
            }
            if (d.cableNamingMode) {
                cableNamingMode = d.cableNamingMode;
                const cnEl = document.getElementById('cableNaming');
                if (cnEl) cnEl.value = cableNamingMode;
            }
            if (d.projectName) {
                projectName = d.projectName;
                document.getElementById('projectName').value = projectName;
            }
            if (d.colors) {
                CONFIG.colors = { ...CONFIG.colors, ...d.colors };
                const cct = document.getElementById('colorCableTag');
                if (cct) cct.value = CONFIG.colors.cable;
                const cwt = document.getElementById('colorWireText');
                if (cwt) cwt.value = CONFIG.colors.wireText;
                const cs = document.getElementById('colorShield');
                if (cs) cs.value = CONFIG.colors.shield;
            }
        } catch (e) {
            console.warn('Error loading autosave', e);
            sheets = [createEmptySheet()];
        }
    } else {
        sheets = [createEmptySheet()];
    }

    // Restore last file name in path display
    const lastFile = localStorage.getItem('loopCAD_lastFile');
    const pathEl = document.getElementById('projectPathDisplay');
    if (pathEl && lastFile) pathEl.textContent = lastFile;

    buildLoopButtons();
    updateSheetUI();

    const inputs = document.querySelectorAll('.equipment-bar input, .equipment-bar textarea, .equipment-bar select, .properties-panel input, .properties-panel textarea, .properties-panel select');
    inputs.forEach(el => {
        const handler = (e) => {
            updateCurrentLoopFromUI(e);
            renderScene();
        };
        el.addEventListener('input', handler);
        el.addEventListener('change', handler);
    });

    document.getElementById('jbEnabled').addEventListener('change', updateUIState);
    document.getElementById('marshEnabled').addEventListener('change', updateUIState);
    document.getElementById('instCategory').addEventListener('change', updateUIState);

    document.getElementById('btnSave').addEventListener('click', saveProject);
    document.getElementById('fileLoad').addEventListener('change', loadProject);
    document.getElementById('btnExportPDF').addEventListener('click', exportPDF);
    document.getElementById('btnExportDXF').addEventListener('click', () => {
        const fn = (projectName || 'proyecto_lazos') + '.dxf';
        exportDXF(fn);
    });









    // Project Name specifically
    // Color pickers and project name handled by general inputs above if they have the class
    // But let's double check CONFIG updates
    document.getElementById('projectName').addEventListener('input', (e) => { projectName = e.target.value; autoSaveToBrowser(); });

    if (document.getElementById('cableNaming')) {
        document.getElementById('cableNaming').addEventListener('change', (e) => { cableNamingMode = e.target.value; autoSaveToBrowser(); });
    }

    canvas.addEventListener('wheel', (e) => {
        if (e.ctrlKey || e.metaKey) {
            e.preventDefault();
            const delta = e.deltaY > 0 ? 0.9 : 1.1;
            canvasScale *= delta;
            canvasScale = Math.max(0.2, Math.min(5, canvasScale));
            renderScene();
        }
    }, { passive: false });

    document.getElementById('btnNew').addEventListener('click', () => {
        if (confirm('¿Desea crear un NUEVO PROYECTO? Se borrarán todas las hojas.')) {
            sheets = [createEmptySheet()];
            currentSheetIndex = 0;
            currentLoopIndex = 0;
            projectName = '';
            document.getElementById('projectName').value = '';
            buildLoopButtons();
            updateSheetUI();
            loadLoopToUI(0);
            renderScene();
        }
    });

    // Add a specific listener for a separate "New Sheet" button if we add one
    // or keep btnNextSheet as the primary way.

    document.getElementById('btnPrevSheet').addEventListener('click', () => {
        if (currentSheetIndex > 0) {
            updateCurrentLoopFromUI();
            currentSheetIndex--;
            currentLoopIndex = 0;
            updateSheetUI();
            loadLoopToUI(0);
            renderScene();
        }
    });

    document.getElementById('btnNextSheet').addEventListener('click', () => {
        updateCurrentLoopFromUI();
        if (currentSheetIndex < sheets.length - 1) {
            currentSheetIndex++;
            currentLoopIndex = 0;
            updateSheetUI();
            loadLoopToUI(0);
            renderScene();
        }
    });

    document.getElementById('btnAddSheet').addEventListener('click', () => {
        updateCurrentLoopFromUI();
        sheets.push(createBlankSheet());
        currentSheetIndex = sheets.length - 1;
        currentLoopIndex = 0;
        updateSheetUI();
        loadLoopToUI(0);
        renderScene();
    });

    document.getElementById('btnDeleteSheet').addEventListener('click', () => {
        if (sheets.length <= 1) {
            alert('No se puede borrar la única hoja del proyecto.');
            return;
        }
        if (confirm(`¿Está seguro de que desea BORRAR COMPLETAMENTE la Hoja ${currentSheetIndex + 1}? Esta acción no se puede deshacer.`)) {
            sheets.splice(currentSheetIndex, 1);
            if (currentSheetIndex >= sheets.length) {
                currentSheetIndex = sheets.length - 1;
            }
            currentLoopIndex = 0;
            updateSheetUI();
            loadLoopToUI(0);
            renderScene();
            autoSaveToBrowser();
        }
    });

    document.getElementById('btnClearLoop').addEventListener('click', clearLoopData);
    document.getElementById('btnDuplicateLoop').addEventListener('click', duplicateLoopData);

    const btnDiag = document.getElementById('btnViewDiagram');
    const btnCables = document.getElementById('btnViewCableList');
    const btnBoxes = document.getElementById('btnViewBoxDiagram');
    const diagView = document.getElementById('diagramView');
    const cableView = document.getElementById('cableListView');
    const boxView = document.getElementById('boxDiagramView');

    function switchView(activeBtn, activeView) {
        updateCurrentLoopFromUI();

        // Clear active classes from all buttons
        [btnDiag, btnCables, btnBoxes].forEach(b => {
            b.classList.remove('active-view');
            b.classList.remove('btn-blue');
            b.classList.remove('btn-orange');
        });

        // Add correct class to the active button
        if (activeBtn === btnDiag) activeBtn.classList.add('active-view');
        if (activeBtn === btnCables) activeBtn.classList.add('btn-blue');
        if (activeBtn === btnBoxes) activeBtn.classList.add('btn-orange');

        [diagView, cableView, boxView].forEach(v => v.classList.remove('active'));
        activeView.classList.add('active');
    }

    btnDiag.addEventListener('click', () => { switchView(btnDiag, diagView); renderScene(); });
    btnCables.addEventListener('click', () => { switchView(btnCables, cableView); showCableList(); });
    btnBoxes.addEventListener('click', () => { switchView(btnBoxes, boxView); renderBoxDiagrams(); });

    document.getElementById('btnRefreshBoxes').addEventListener('click', renderBoxDiagrams);

    document.getElementById('btnExportListCSV_New').addEventListener('click', exportCableList);

    // ── Login & Access Control (v2.1.5) ──────────────────────────────────────
    const loginModal = document.getElementById('loginModal');
    const btnLogin = document.getElementById('btnLogin');
    const btnConfirmLogin = document.getElementById('btnConfirmLogin');
    const btnCancelLogin = document.getElementById('btnCancelLogin');
    const loginUser = document.getElementById('loginUser');
    const loginPass = document.getElementById('loginPass');

    if (btnLogin) {
        btnLogin.addEventListener('click', () => {
            if (isUserLoggedIn) {
                if (confirm('¿Desea cerrar la sesión de gestión?')) {
                    isUserLoggedIn = false;
                    loggedInUser = '';       // Limpiar usuario al salir
                    updateAccessControl();
                }
            } else {
                loginModal.style.display = 'flex';
                loginUser.focus();
            }
        });
    }

    if (btnConfirmLogin) {
        btnConfirmLogin.addEventListener('click', () => {
            const u = loginUser.value.trim();
            const p = loginPass.value.trim();
            const valid = (u === 'jmg' && p === '4321') ||
                          (u === 'TRESCA' && p === 'TRESCA');
            if (valid) {
                isUserLoggedIn = true;
                loggedInUser = u;           // Guardar nombre de usuario activo
                loginModal.style.display = 'none';
                loginUser.value = '';
                loginPass.value = '';
                updateAccessControl();
            } else {
                alert('Credenciales incorrectas. Acceso denegado.');
            }
        });
    }

    if (btnCancelLogin) {
        btnCancelLogin.addEventListener('click', () => {
            loginModal.style.display = 'none';
            loginUser.value = '';
            loginPass.value = '';
        });
    }

    if (loginPass) {
        loginPass.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') btnConfirmLogin.click();
        });
    }

    updateAccessControl();

    loadLoopToUI(0);
    renderScene();
}

function buildLoopButtons() {
    const btnContainer = document.getElementById('loopButtons');
    btnContainer.innerHTML = '';
    for (let i = 0; i < 12; i++) {
        const btn = document.createElement('button');
        btn.textContent = `${i + 1}`;
        btn.className = (i === 0) ? 'loop-btn active' : 'loop-btn';
        btn.onclick = () => selectLoop(i);
        btnContainer.appendChild(btn);
    }
}

function updateSheetUI() {
    const el = document.getElementById('sheetLabel');
    if (el) el.textContent = `Hoja ${currentSheetIndex + 1} / ${sheets.length}`;
    // highlight active loop button
    const btns = document.querySelectorAll('.loop-btn');
    const loops = getCurrentLoops();
    btns.forEach((b, i) => {
        let stateClass = 'empty';
        if (loops[i] && loops[i].instTag && loops[i].instTag.trim() !== '') {
            stateClass = 'populated';
        }

        b.className = (i === currentLoopIndex) ? 'loop-btn active' : `loop-btn ${stateClass}`;
    });
    const titleEl = document.getElementById('currentLoopTitle');
    if (titleEl) {
        titleEl.textContent = `PROPIEDADES LAZO ${currentLoopIndex + 1} — HOJA ${currentSheetIndex + 1}`;
    }

    const activeLabelEl = document.getElementById('activeLoopLabel');
    if (activeLabelEl) {
        activeLabelEl.textContent = `Lazo: ${currentLoopIndex + 1} | Hoja: ${currentSheetIndex + 1}`;
    }
}

function updateAccessControl() {
    const restrictedButtons = document.querySelectorAll('.btn-restricted');
    const loginBtn = document.getElementById('btnLogin');

    if (isUserLoggedIn) {
        restrictedButtons.forEach(btn => {
            btn.classList.remove('blocked');
            btn.disabled = false;
        });
        if (loginBtn) {
            loginBtn.textContent = 'Salir (' + loggedInUser + ')';
            loginBtn.classList.add('btn-logged-in');
            loginBtn.classList.remove('btn-dark');
        }
    } else {
        restrictedButtons.forEach(btn => {
            btn.classList.add('blocked');
            btn.disabled = true;
        });
        if (loginBtn) {
            loginBtn.textContent = 'Acceder';
            loginBtn.classList.remove('btn-logged-in');
            loginBtn.classList.add('btn-dark');
        }
    }
}

// ── Loop selection ─────────────────────────────────────────────────────────────
function selectLoop(index) {
    updateCurrentLoopFromUI();
    currentLoopIndex = index;
    updateSheetUI();
    loadLoopToUI(index);

    // Auto-scroll to loop on canvas
    const wrapper = document.querySelector('.canvas-wrapper');
    if (wrapper) {
        const startY = 440;
        const rowH = 350;
        const targetY = (startY + (index * rowH)) * canvasScale - 100;
        wrapper.scrollTo({
            top: targetY,
            behavior: 'smooth'
        });
    }
}

function loadLoopToUI(index) {
    const data = getCurrentLoops()[index];
    if (!data) return;
    const setVal = (id, v) => { const el = document.getElementById(id); if (el) el.value = v ?? ''; };
    const setChk = (id, v) => { const el = document.getElementById(id); if (el) el.checked = !!v; };

    setVal('projectName', projectName);

    setVal('instTag', data.instTag);
    setVal('instType', data.instType);
    setVal('instCategory', data.instCategory || 'STD');
    const iterms = data.instTerms || ['', '', '', '', '', '', '', ''];
    const ihilos = data.instHilos || ['', '', '', '', '', '', '', ''];
    for (let i = 0; i < 8; i++) {
        setVal(`instTerm${i + 1}`, iterms[i]);
        setVal(`instHilo${i + 1}`, ihilos[i]);
    }

    const signalNames = data.signalNames || ['', '', '', ''];
    for (let i = 0; i < 4; i++) setVal(`sigName${i + 1}`, signalNames[i]);

    setVal('cable1Tag', data.cable1Tag);
    setVal('cable1Section', data.cable1Section);
    setVal('cable1Len', data.cable1Len || 0);
    setChk('cable1Shield', data.cable1Shield);
    setChk('cable1Armor', data.cable1Armor);

    setChk('jbEnabled', data.jbEnabled !== false);
    setVal('jbTag', data.jbTag);
    setVal('jbModule', data.jbModule);
    setVal('jbMaxTerms', data.jbMaxTerms || 48);
    for (let i = 0; i < 8; i++) {
        setVal(`jbTerm${i + 1}`, (data.jbTerms && data.jbTerms[i]) || '');
    }
    setVal('jbTermSh', data.jbTermSh || 'PE');

    // jbHilos
    const jbHilos = data.jbHilos || { inPos: '', outPos: '', inNeg: '', outNeg: '', inSh: '', outSh: '' };
    setVal('jbHiloInPos', jbHilos.inPos);
    setVal('jbHiloOutPos', jbHilos.outPos);
    setVal('jbHiloInNeg', jbHilos.inNeg);
    setVal('jbHiloOutNeg', jbHilos.outNeg);
    setVal('jbHiloInSh', jbHilos.inSh);
    setVal('jbHiloOutSh', jbHilos.outSh);

    setVal('cable2Tag', data.cable2Tag);
    setVal('cable2Section', data.cable2Section);
    setVal('cable2Len', data.cable2Len || 0);
    setChk('cable2Shield', data.cable2Shield);
    setChk('cable2Armor', data.cable2Armor);

    setChk('marshEnabled', data.marshEnabled !== false);
    setVal('marshTag', data.marshTag);
    setVal('marshModule', data.marshModule);
    setVal('marshMaxTerms', data.marshMaxTerms || 48);
    for (let i = 0; i < 8; i++) {
        setVal(`marshTerm${i + 1}`, (data.marshTerms && data.marshTerms[i]) || '');
    }
    setVal('marshTermInSh', data.marshTermInSh || 'PE');

    // marshHilos
    const marshHilos = data.marshHilos || { inPos: '', outPos: '', inNeg: '', outNeg: '', inSh: '', outSh: '' };
    setVal('marshHiloInPos', marshHilos.inPos);
    setVal('marshHiloOutPos', marshHilos.outPos);
    setVal('marshHiloInNeg', marshHilos.inNeg);
    setVal('marshHiloOutNeg', marshHilos.outNeg);
    setVal('marshHiloInSh', marshHilos.inSh);
    setVal('marshHiloOutSh', marshHilos.outSh);

    setVal('cableSysTag', data.cableSysTag);
    setVal('cableSysSection', data.cableSysSection);
    setVal('cableSysLen', data.cableSysLen || 0);
    setChk('cableSysShield', data.cableSysShield);
    setChk('cableSysArmor', data.cableSysArmor);

    setVal('plcTag', data.plcTag);
    setVal('plcModule', data.plcModule);
    for (let i = 0; i < 8; i++) {
        setVal(`plcTerm${i + 1}`, (data.plcTerms && data.plcTerms[i]) || '');
    }
    setVal('plcTermPe', data.plcTermPe || 'PE');

    // plcHilos
    const ph = data.plcHilos || { h1: '', h2: '', h3: '', h4: '', h5: '', h6: '', h7: '', h8: '', hPe: '' };
    for (let i = 1; i <= 8; i++) setVal(`plcHilo${i}`, ph[`h${i}`]);
    setVal('plcHiloPe', ph.hPe);

    setVal('plcDetails', data.plcDetails);

    updateUIState();
}

function updateUIState() {
    const loop = getCurrentLoops()[currentLoopIndex];
    const category = document.getElementById('instCategory').value;
    const jbEn = document.getElementById('jbEnabled').checked;
    const marshEn = document.getElementById('marshEnabled').checked;

    // Show/Hide instrument terminals
    const tCount = category === 'STD' ? 2 : (category === '3W' ? 3 : (category === 'VALVE' ? 6 : 8));
    for (let i = 0; i < 8; i++) {
        const elT = document.getElementById(`instTerm${i + 1}`);
        const elH = document.getElementById(`instHilo${i + 1}`);
        const display = i < tCount ? 'block' : 'none';
        if (elT) elT.style.display = display;
        if (elH) elH.style.display = display;
    }

    // Show/Hide signal descriptions based on category
    const sigNamesContainer = document.getElementById('sigNamesContainer')?.parentElement;
    if (sigNamesContainer) {
        sigNamesContainer.style.display = 'flex'; // Always show now

        const s1 = document.getElementById('sigName1');
        const s2 = document.getElementById('sigName2');
        const s3 = document.getElementById('sigName3');
        const s4 = document.getElementById('sigName4');

        const sigsToShow = (category === 'VALVE') ? 3 : (category === 'MOTOR' ? 4 : 1);

        if (s1) s1.style.display = sigsToShow >= 1 ? 'block' : 'none';
        if (s2) s2.style.display = sigsToShow >= 2 ? 'block' : 'none';
        if (s3) s3.style.display = sigsToShow >= 3 ? 'block' : 'none';
        if (s4) s4.style.display = sigsToShow >= 4 ? 'block' : 'none';

        // Show/Hide PLC terminals (Phase 11)
        for (let i = 0; i < 8; i++) {
            const elT = document.getElementById(`plcTerm${i + 1}`);
            const elH = document.getElementById(`plcHilo${i + 1}`);
            const display = i < tCount ? 'block' : 'none';
            if (elT) elT.style.display = display;
            if (elH) elH.style.display = display;
        }
    }

    const jbFields = document.getElementById('jbFields');
    const marshFields = document.getElementById('marshFields');
    const cable2Group = document.getElementById('cable2Group');
    const cableSysGroup = document.getElementById('cableSysGroup');

    if (jbFields) {
        jbFields.querySelectorAll('input:not([type="checkbox"]), textarea, select').forEach(el => el.disabled = !jbEn);
        jbFields.style.opacity = jbEn ? '1' : '0.5';
    }
    if (marshFields) {
        marshFields.querySelectorAll('input:not([type="checkbox"]), textarea, select').forEach(el => el.disabled = !marshEn);
        marshFields.style.opacity = marshEn ? '1' : '0.5';
    }

    if (cable2Group) cable2Group.style.visibility = jbEn ? 'visible' : 'hidden';
    if (cableSysGroup) cableSysGroup.style.visibility = marshEn ? 'visible' : 'hidden';
}

function clearLoopData() {
    if (confirm('¿Borrar todos los datos del lazo actual?')) {
        getCurrentLoops()[currentLoopIndex] = createBlankLoop(currentLoopIndex);
        loadLoopToUI(currentLoopIndex);
        renderScene();
        autoSaveToBrowser();
    }
}

function duplicateLoopData() {
    if (currentLoopIndex < 11) {
        const currentData = JSON.parse(JSON.stringify(getCurrentLoops()[currentLoopIndex]));
        currentData.id = currentLoopIndex + 1;
        getCurrentLoops()[currentLoopIndex + 1] = currentData;

        // Auto-select the next loop to show it was copied
        selectLoop(currentLoopIndex + 1);
        renderScene();
        autoSaveToBrowser();
    } else {
        alert('No se puede duplicar en el último lazo de la hoja.');
    }
}

function updateCurrentLoopFromUI(e) {
    const loop = getCurrentLoops()[currentLoopIndex];
    if (!loop) return;

    const getVal = (id) => { const el = document.getElementById(id); return el ? el.value : ''; };
    const getChk = (id) => { const el = document.getElementById(id); return el ? el.checked : false; };

    // Auto-update logic for Instrument Tag
    if (e && e.target.id === 'instTag') {
        const newTag = e.target.value;
        // Auto-update Cable 1 tag: W + InstrumentTag (as requested previously)
        loop.cable1Tag = `W${newTag}`;
        const c1el = document.getElementById('cable1Tag');
        if (c1el) c1el.value = loop.cable1Tag;

        // Update Signal in PLC Details
        if (loop.plcDetails && loop.plcDetails.includes('Señal:')) {
            loop.plcDetails = loop.plcDetails.replace(/Señal:[^\n]*/, `Señal: ${newTag}`);
        } else if (!loop.plcDetails || !loop.plcDetails.trim()) {
            loop.plcDetails = `Señal: ${newTag}`;
        }
        const pdel = document.getElementById('plcDetails');
        if (pdel) pdel.value = loop.plcDetails;
    }

    loop.instTag = getVal('instTag');
    loop.instType = getVal('instType');
    loop.instCategory = getVal('instCategory');

    // Sync instTerms and instHilos
    if (!loop.instTerms) loop.instTerms = ['', '', '', '', '', '', '', ''];
    if (!loop.instHilos) loop.instHilos = ['', '', '', '', '', '', '', ''];
    for (let i = 0; i < 8; i++) {
        loop.instTerms[i] = getVal(`instTerm${i + 1}`);
        loop.instHilos[i] = getVal(`instHilo${i + 1}`);
    }

    // Sync signalNames
    if (!loop.signalNames) loop.signalNames = ['', '', '', ''];
    for (let i = 0; i < 4; i++) {
        loop.signalNames[i] = getVal(`sigName${i + 1}`);
    }

    loop.cable1Tag = getVal('cable1Tag');
    loop.cable1Section = getVal('cable1Section');
    loop.cable1Len = parseFloat(getVal('cable1Len')) || 0;
    loop.cable1Shield = getChk('cable1Shield');
    loop.cable1Armor = getChk('cable1Armor');

    loop.jbEnabled = getChk('jbEnabled');
    loop.jbTag = getVal('jbTag');
    loop.jbModule = getVal('jbModule');
    loop.cable2Tag = getVal('cable2Tag');
    loop.cable2Section = getVal('cable2Section');
    loop.cable2Len = parseFloat(getVal('cable2Len')) || 0;
    loop.cable2Shield = getChk('cable2Shield');
    loop.cable2Armor = getChk('cable2Armor');

    loop.marshEnabled = getChk('marshEnabled');
    loop.marshTag = getVal('marshTag');
    loop.marshModule = getVal('marshModule');
    loop.marshMaxTerms = parseInt(getVal('marshMaxTerms'), 10) || 48;

    loop.cableSysTag = getVal('cableSysTag');
    loop.cableSysSection = getVal('cableSysSection');
    loop.cableSysLen = parseFloat(getVal('cableSysLen')) || 0;
    loop.cableSysShield = getChk('cableSysShield');
    loop.cableSysArmor = getChk('cableSysArmor');

    loop.plcTag = getVal('plcTag');
    loop.plcModule = getVal('plcModule');
    loop.plcTermPe = getVal('plcTermPe');
    loop.plcDetails = getVal('plcDetails');

    loop.plcTerms = [];
    for (let i = 1; i <= 8; i++) {
        loop.plcTerms.push(getVal(`plcTerm${i}`));
    }

    loop.plcHilos = {
        h1: getVal('plcHilo1'),
        h2: getVal('plcHilo2'),
        h3: getVal('plcHilo3'),
        h4: getVal('plcHilo4'),
        h5: getVal('plcHilo5'),
        h6: getVal('plcHilo6'),
        h7: getVal('plcHilo7'),
        h8: getVal('plcHilo8'),
        hPe: getVal('plcHiloPe')
    };

    if (loop.jbEnabled) {
        loop.jbTerms = [];
        for (let i = 1; i <= 8; i++) loop.jbTerms.push(getVal(`jbTerm${i}`));
        loop.jbTermSh = getVal('jbTermSh') || 'PE';

        loop.jbHilos = {
            inPos: getVal('jbHiloInPos'), outPos: getVal('jbHiloOutPos'),
            inNeg: getVal('jbHiloInNeg'), outNeg: getVal('jbHiloOutNeg'),
            inSh: getVal('jbHiloInSh'), outSh: getVal('jbHiloOutSh')
        };
    }
    if (loop.marshEnabled) {
        loop.marshTerms = [];
        for (let i = 1; i <= 8; i++) loop.marshTerms.push(getVal(`marshTerm${i}`));
        loop.marshTermInSh = getVal('marshTermInSh') || 'PE';

        loop.marshHilos = {
            inPos: getVal('marshHiloInPos'), outPos: getVal('marshHiloOutPos'),
            inNeg: getVal('marshHiloInNeg'), outNeg: getVal('marshHiloOutNeg'),
            inSh: getVal('marshHiloInSh'), outSh: getVal('marshHiloOutSh')
        };
    }

    findDuplicates();
    markDuplicatesUI();
    autoSaveToBrowser();
}

function findDuplicates() {
    const instCount = {};
    const cableCountMap = {};
    duplicateTags.clear();
    duplicateCables.clear();

    sheets.forEach(sheet => {
        sheet.forEach(loop => {
            // Check Instrument Tags
            if (loop.instTag && loop.instTag.trim() !== '') {
                const t = loop.instTag.trim().toUpperCase();
                instCount[t] = (instCount[t] || 0) + 1;
            }
            // Check ONLY Instrument Cable (Cable 1)
            if (cableNamingMode === 'TAG') {
                const cNames = buildCableNames(loop, 1, () => { });
                // We only care about cNames.c1 for duplicates as per user request
                const c1 = cNames.c1;
                if (c1 && c1.trim() !== '' && c1 !== 'N/A') {
                    const tc = c1.trim().toUpperCase();
                    cableCountMap[tc] = (cableCountMap[tc] || 0) + 1;
                }
            }
        });
    });

    for (const t in instCount) { if (instCount[t] > 1) duplicateTags.add(t); }
    for (const c in cableCountMap) { if (cableCountMap[c] > 1) duplicateCables.add(c); }
}

function markDuplicatesUI() {
    const it = document.getElementById('instTag');
    if (it) {
        const val = it.value.trim().toUpperCase();
        it.style.color = duplicateTags.has(val) ? '#ff5555' : '';
        it.style.fontWeight = duplicateTags.has(val) ? 'bold' : '';
    }
}

// ── AutoSave ─────────────────────────────────────────────────────────────────
function autoSaveToBrowser() {
    const data = JSON.stringify({ sheets, cableNamingMode, projectName, colors: CONFIG.colors });
    localStorage.setItem('loopCAD_autosave', data);
}

// ── Render ─────────────────────────────────────────────────────────────────────
function renderScene() {
    const wrapper = document.querySelector('.canvas-wrapper');
    const bar = document.querySelector('.equipment-bar');

    const scaledW = CONFIG.canvasWidth * canvasScale;
    const scaledH = CONFIG.canvasHeight * canvasScale;

    if (wrapper) {
        wrapper.style.width = scaledW + 'px';
        wrapper.style.height = scaledH + 'px';
        wrapper.style.position = 'relative';
        wrapper.style.display = 'block';
    }

    if (canvas) {
        canvas.style.width = scaledW + 'px';
        canvas.style.height = scaledH + 'px';
        canvas.style.position = 'relative';
        canvas.style.top = '0';
    }

    // Reset bar styles
    if (bar) {
        bar.style.transform = 'none';
        bar.style.position = 'relative';
        bar.style.top = '0';
        bar.style.left = '0';
    }

    findDuplicates(); // v2.0.5: Call validation
    markDuplicatesUI(); // v2.0.5: Call validation UI update

    ctx.fillStyle = CONFIG.colors.bg;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    drawGrid();
    drawHeaderTable();

    const startY = 480; // Bajado de 440 para dejar más espacio superior
    const rowH = 350; // Increased to 350px to ensure no overlaps even with 8 wires

    let cableCount = getGlobalCableCount(currentSheetIndex);
    const loops = getCurrentLoops();
    const cableWireMap = {}; // Phase 8: track wire index per cable tag

    loops.forEach((loop, i) => {
        const y = startY + (i * rowH);

        ctx.fillStyle = CONFIG.colors.text;
        ctx.font = "bold 24px Arial";
        ctx.textAlign = 'center';
        ctx.fillText(i + 1, 40, y);

        if (loop.instTag && loop.instTag.trim() !== '') {
            drawRow(loop, y, buildCableNames(loop, cableCount, (n) => { cableCount = n; }), cableWireMap);
        }
    });

    markDuplicatesUI();
}

function buildCableNames(loop, cableCount, setCableCount) {
    let dest1 = loop.plcTag || 'PLC';
    if (loop.marshEnabled) dest1 = loop.marshTag || 'MRSH';
    if (loop.jbEnabled) dest1 = loop.jbTag || 'JB';

    let dest2 = loop.plcTag || 'PLC';
    if (loop.marshEnabled) dest2 = loop.marshTag || 'MRSH';

    const dest3 = loop.plcTag || 'PLC';

    let c1 = '', c2 = '', c3 = '';
    let cnt = cableCount;
    const pad = (n) => n.toString().padStart(3, '0');

    if (cableNamingMode === 'AUTO') {
        c1 = `W-${pad(cnt++)}/${dest1}`;
        if (loop.jbEnabled) c2 = `W-${pad(cnt++)}/${dest2}`;
        if (loop.marshEnabled) c3 = `W-${pad(cnt++)}/${dest3}`;
    } else {
        c1 = `W${loop.instTag || 'TAG'}/${dest1}`;
        if (loop.jbEnabled) {
            const suffix = loop.cable2Tag ? `-${loop.cable2Tag}` : '';
            c2 = `${loop.jbTag || 'JB'}${suffix}/${dest2}`;
        }
        if (loop.marshEnabled) {
            const suffix = loop.cableSysTag ? `-${loop.cableSysTag}` : '';
            c3 = `${loop.marshTag || 'MRSH'}${suffix}/${dest3}`;
        }
    }

    if (setCableCount) setCableCount(cnt);
    return { c1, c2, c3 };
}

function getGlobalCableCount(uptoSheetIndex) {
    let count = 1;
    for (let s = 0; s < uptoSheetIndex; s++) {
        sheets[s].forEach(loop => {
            const hasData = loop.instTag && loop.instTag.trim() !== '';
            if (!hasData) return;
            // Count cables for this loop:
            // Always at least 1 cable (INST→first_stop or INST→PLC)
            // +1 if JB enabled (JB→MARSH or JB→PLC)
            // +1 if MARSH enabled (MARSH→PLC)
            let cablesInLoop = 1;
            if (loop.jbEnabled) cablesInLoop++;
            if (loop.marshEnabled) cablesInLoop++;
            count += cablesInLoop;
        });
    }
    return count;
}

function drawGrid() { /* Optional */ }

function drawHeaderTable() {
    const W = CONFIG.canvasWidth;
    const H = 80;
    ctx.lineWidth = 2;
    ctx.strokeStyle = CONFIG.colors.line;
    ctx.strokeRect(0, 0, W, H);

    ctx.beginPath(); ctx.moveTo(0, 40); ctx.lineTo(W, 40); ctx.stroke();
    const splitX = W * 0.45;
    ctx.beginPath(); ctx.moveTo(splitX, 0); ctx.lineTo(splitX, H); ctx.stroke();

    ctx.fillStyle = CONFIG.colors.text;
    ctx.font = CONFIG.fonts.header;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`CAMPO — Hoja ${currentSheetIndex + 1}`, splitX / 2, 20);
    ctx.fillText("EDIFICIO DE CONTROL", splitX + (W - splitX) / 2, 20);

    // Project Name in the middle bottom of header or similar?
    // Let's put it in a new row or top left?
    // User asked for it as a parameter, common to show in header or footer.
    // Let's add it to the header area.
    ctx.font = CONFIG.fonts.subHeader;
    ctx.textAlign = 'left';
    ctx.fillText(`PROYECTO: ${projectName}`, 10, 20);

    const cols = getCols();
    ctx.font = CONFIG.fonts.subHeader;
    ctx.textAlign = 'center';
    ctx.fillText("INSTRUMENTO", cols.inst, 60);
    ctx.fillText("CAJA DE AGRUPACIÓN", cols.jb, 60);
    ctx.fillText("MARSHALLING", cols.marsh, 60);
    ctx.fillText("ARMARIO DE CONTROL", cols.plc, 60);
}

function getCols() {
    const W = CONFIG.canvasWidth;
    return {
        inst: 210,   // Moved 40px left (250 - 40)
        jb: 660,     // Moved 40px left (700 - 40)
        marsh: 1110, // Moved 40px left (1150 - 40)
        plc: 1564    // Moved 40px left (1604 - 40)
    };
}

function drawRow(loop, y, cableNames, wireMap) {
    const instTag = (loop.instTag || '').trim().toUpperCase();
    const isDup = duplicateTags.has(instTag);

    // Instrument
    const oldFill = ctx.fillStyle;
    if (isDup) ctx.fillStyle = '#ff5555';
    drawInstrument(loop, getCols().inst, y);
    ctx.fillStyle = oldFill;

    if (loop.jbEnabled) drawJB(loop, getCols().jb, y);
    if (loop.marshEnabled) drawMarsh(loop, getCols().marsh, y);
    drawPLC(loop, getCols().plc, y);

    // Cables
    let lc = 'INST';
    if (loop.jbEnabled) {
        const c1isDup = duplicateCables.has(cableNames.c1.trim().toUpperCase());
        drawCable(getCols().inst, getCols().jb, y,
            { tag: cableNames.c1, sec: loop.cable1Section, sh: loop.cable1Shield, arm: loop.cable1Armor, isDup: c1isDup },
            'INST-JB', loop, wireMap);
        lc = 'JB';
    }
    if (loop.marshEnabled) {
        const s = lc === 'INST' ? getCols().inst : getCols().jb;
        const tag = lc === 'INST' ? cableNames.c1 : cableNames.c2;
        const ctype = lc === 'INST' ? 'INST-MARSH' : 'JB-MARSH';
        const sec = lc === 'INST' ? loop.cable1Section : loop.cable2Section;
        const sh = lc === 'INST' ? loop.cable1Shield : loop.cable2Shield;
        const arm = lc === 'INST' ? loop.cable1Armor : loop.cable2Armor;
        const cDup = duplicateCables.has(tag.trim().toUpperCase());
        drawCable(s, getCols().marsh, y, { tag, sec, sh, arm, isDup: cDup }, ctype, loop, wireMap);
        lc = 'MARSH';
    }

    const s3 = lc === 'MARSH' ? getCols().marsh : (lc === 'JB' ? getCols().jb : getCols().inst);
    const t3 = lc === 'MARSH' ? cableNames.c3 : (lc === 'JB' ? cableNames.c2 : cableNames.c1);
    const ty3 = lc === 'MARSH' ? 'MARSH-PLC' : (lc === 'JB' ? 'JB-PLC' : 'INST-PLC');
    const sec3 = lc === 'MARSH' ? loop.cableSysSection : (lc === 'JB' ? loop.cable2Section : loop.cable1Section);
    const sh3 = lc === 'MARSH' ? loop.cableSysShield : (lc === 'JB' ? loop.cable2Shield : loop.cable1Shield);
    const arm3 = lc === 'MARSH' ? loop.cableSysArmor : (lc === 'JB' ? loop.cable2Armor : loop.cable1Armor);
    const c3Dup = duplicateCables.has(t3.trim().toUpperCase());
    drawCable(s3, getCols().plc, y, { tag: t3, sec: sec3, sh: sh3, arm: arm3, isDup: c3Dup }, ty3, loop, wireMap);
}

// ── Component drawing ──────────────────────────────────────────────────────────
function drawInstrument(loop, x, y) {
    const r = 30;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.lineWidth = 2;
    ctx.strokeStyle = CONFIG.colors.line;
    ctx.fillStyle = CONFIG.colors.text;
    ctx.stroke();

    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const fullTag = (loop.instTag || '').trim();
    if (fullTag.length > 0) {
        ctx.beginPath();
        ctx.moveTo(x - r, y); ctx.lineTo(x + r, y); ctx.stroke();

        const hyphenIndex = fullTag.indexOf('-');
        let topPart = '';
        let bottomPart = '';

        if (hyphenIndex !== -1) {
            topPart = fullTag.substring(0, hyphenIndex);
            bottomPart = fullTag.substring(hyphenIndex + 1);
        } else {
            topPart = fullTag;
            bottomPart = '';
        }

        const maxWidth = r * 2 - 4;

        // Top Part
        ctx.font = CONFIG.fonts.tag;
        let w1 = ctx.measureText(topPart).width;
        if (w1 > maxWidth) {
            ctx.font = `bold ${Math.floor(18 * (maxWidth / w1))}px "Consolas", monospace`;
        }
        ctx.fillText(topPart, x, bottomPart ? y - 10 : y - 2);

        // Bottom Part
        if (bottomPart) {
            ctx.font = CONFIG.fonts.tag;
            let w2 = ctx.measureText(bottomPart).width;
            if (w2 > maxWidth) {
                ctx.font = `bold ${Math.floor(18 * (maxWidth / w2))}px "Consolas", monospace`;
            }
            ctx.fillText(bottomPart, x, y + 10);
        }
    }

    // Borneras apiladas verticalmente, centradas en y
    const termSize = 15;
    const tx = x + r;
    const category = loop.instCategory || 'STD';

    if (!loop.instTerms) loop.instTerms = [loop.instTermPos || '+', loop.instTermNeg || '-', '3', '4', '5', '6', '7', '8'];

    const termCount = category === 'STD' ? 2 : (category === '3W' ? 3 : (category === 'VALVE' ? 6 : 8));
    const startTermY = y - ((termCount - 1) * 20) / 2;

    for (let i = 0; i < termCount; i++) {
        const ty = startTermY + (i * 20);
        drawTermSquare(tx, ty - 7.5, loop.instTerms[i] || (i + 1).toString());

        // Draw Instrument Hilos - v2.1.3 fix
        const hilos = loop.instHilos || [];
        const hTag = hilos[i];
        if (hTag) {
            ctx.fillStyle = CONFIG.colors.wireText;
            ctx.font = CONFIG.fonts.wire;
            ctx.textAlign = 'left';
            ctx.fillText(hTag, tx + termSize + 3, ty - 3);
        }
    }

    // Tipo de instrumento — bajado
    ctx.font = CONFIG.fonts.small;
    ctx.textAlign = 'center';
    ctx.fillText(loop.instType, x, y + r + 22);
}

function drawTermSquare(x, y, txt, width = 15) {
    const h = 15;
    const w = width;
    ctx.lineWidth = 1;
    ctx.strokeStyle = CONFIG.colors.line;
    ctx.strokeRect(x, y, w, h);
    ctx.fillStyle = CONFIG.colors.text;
    ctx.font = CONFIG.fonts.small;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(txt, x + w / 2, y + h / 2);
}

function drawJB(loop, x, y) {
    const category = loop.instCategory || 'STD';
    const termCount = category === 'STD' ? 2 : (category === '3W' ? 3 : (category === 'VALVE' ? 6 : 8));
    const h = termCount * 20 + 115; // Increased to include ground symbol inside
    const w = 160; // Widened to 160 to prevent hilo overlap
    const top = y - h / 2;

    ctx.lineWidth = 2;
    ctx.strokeStyle = CONFIG.colors.line;
    ctx.strokeRect(x - w / 2, top, w, h);

    ctx.textAlign = 'center';
    ctx.font = CONFIG.fonts.tag;
    ctx.fillText(loop.jbTag, x, top - 15);

    ctx.fillStyle = CONFIG.colors.text;
    ctx.font = CONFIG.fonts.small;
    ctx.fillText(loop.jbModule || '', x, top + 15);
    ctx.beginPath();
    ctx.moveTo(x - w / 2, top + 25); ctx.lineTo(x + w / 2, top + 25);
    ctx.stroke();
    if (!loop.jbTerms) {
        loop.jbTerms = [loop.jbTermPos || '1', loop.jbTermNeg || '2', '3', '4', '5', '6', '7', '8'];
    }

    const startTermY = y - ((termCount - 1) * 20) / 2;
    for (let i = 0; i < termCount; i++) {
        const ty = startTermY + (i * 20);
        drawTermSquare(x - 20, ty - 7.5, loop.jbTerms[i] || (i + 1).toString(), 40);

        const hilos = loop.jbHilos || {};
        const instH = loop.instHilos || [];
        ctx.fillStyle = CONFIG.colors.wireText;
        ctx.font = CONFIG.fonts.wire;

        if (i === 0) {
            const hIn = hilos.inPos || instH[0];
            const hOut = hilos.outPos || instH[0];
            if (hIn) { ctx.textAlign = 'right'; ctx.fillText(hIn, x - 25, ty - 3); }
            if (hOut) { ctx.textAlign = 'left'; ctx.fillText(hOut, x + 25, ty - 3); }
        } else if (i === 1) {
            const hIn = hilos.inNeg || instH[1];
            const hOut = hilos.outNeg || instH[1];
            if (hIn) { ctx.textAlign = 'right'; ctx.fillText(hIn, x - 25, ty - 3); }
            if (hOut) { ctx.textAlign = 'left'; ctx.fillText(hOut, x + 25, ty - 3); }
        } else {
            // For 3W, Valve, Motor - Use instHilos
            const hTag = instH[i] || '';
            if (hTag) {
                ctx.textAlign = 'right'; ctx.fillText(hTag, x - 25, ty - 3);
                ctx.textAlign = 'left'; ctx.fillText(hTag, x + 25, ty - 3);
            }
        }
    }

    const peLineY = startTermY + (termCount * 20);
    const peBoxY = peLineY + 5;
    drawTermSquare(x - 20, peBoxY, loop.jbTermSh || 'PE', 40);
    drawGroundSymbol(x, peBoxY + 15);

    const hilos = loop.jbHilos || {};
    ctx.fillStyle = CONFIG.colors.wireText;
    ctx.font = CONFIG.fonts.wire;
    if (hilos.inSh) { ctx.textAlign = 'right'; ctx.fillText(hilos.inSh, x - 25, peBoxY - 3 + 7.5); }
    if (hilos.outSh) { ctx.textAlign = 'left'; ctx.fillText(hilos.outSh, x + 25, peBoxY - 3 + 7.5); }
}

function drawMarsh(loop, x, y) {
    const category = loop.instCategory || 'STD';
    const termCount = category === 'STD' ? 2 : (category === '3W' ? 3 : (category === 'VALVE' ? 6 : 8));
    const h = termCount * 20 + 120; // Increased to include ground symbol inside
    const w = 160; // Widened to 160 to prevent hilo overlap
    const top = y - h / 2;

    ctx.lineWidth = 2;
    ctx.strokeStyle = CONFIG.colors.line;
    ctx.strokeRect(x - w / 2, top, w, h);

    ctx.textAlign = 'center';
    ctx.font = CONFIG.fonts.tag;
    ctx.fillText(loop.marshTag, x, top - 15);

    ctx.fillStyle = CONFIG.colors.text;
    ctx.font = CONFIG.fonts.small;
    ctx.fillText(loop.marshModule || '', x, top + 15);
    ctx.beginPath();
    ctx.moveTo(x - w / 2, top + 25); ctx.lineTo(x + w / 2, top + 25);
    ctx.stroke();

    if (!loop.marshTerms) {
        loop.marshTerms = [loop.marshTermInPos || '1', loop.marshTermInNeg || '2', '3', '4', '5', '6', '7', '8'];
    }

    const startTermY = y - ((termCount - 1) * 20) / 2;
    for (let i = 0; i < termCount; i++) {
        const ty = startTermY + (i * 20);
        drawTermSquare(x - 20, ty - 7.5, loop.marshTerms[i] || (i + 1).toString(), 40);

        const hilos = loop.marshHilos || {};
        const instH = loop.instHilos || [];
        ctx.fillStyle = CONFIG.colors.wireText;
        ctx.font = CONFIG.fonts.wire;

        if (i === 0) {
            const hIn = hilos.inPos || instH[0];
            const hOut = hilos.outPos || instH[0];
            if (hIn) { ctx.textAlign = 'right'; ctx.fillText(hIn, x - 25, ty - 3); }
            if (hOut) { ctx.textAlign = 'left'; ctx.fillText(hOut, x + 25, ty - 3); }
        } else if (i === 1) {
            const hIn = hilos.inNeg || instH[1];
            const hOut = hilos.outNeg || instH[1];
            if (hIn) { ctx.textAlign = 'right'; ctx.fillText(hIn, x - 25, ty - 3); }
            if (hOut) { ctx.textAlign = 'left'; ctx.fillText(hOut, x + 25, ty - 3); }
        } else {
            const hTag = instH[i] || '';
            if (hTag) {
                ctx.textAlign = 'right'; ctx.fillText(hTag, x - 25, ty - 3);
                ctx.textAlign = 'left'; ctx.fillText(hTag, x + 25, ty - 3);
            }
        }
    }

    const peLineY = startTermY + (termCount * 20);
    const peBoxY = peLineY + 5;
    drawTermSquare(x - 20, peBoxY, loop.marshTermInSh || 'PE', 40);
    drawGroundSymbol(x, peBoxY + 15);

    const hilos = loop.marshHilos || {};
    ctx.fillStyle = CONFIG.colors.wireText;
    ctx.font = CONFIG.fonts.wire;
    if (hilos.inSh) { ctx.textAlign = 'right'; ctx.fillText(hilos.inSh, x - 25, peBoxY - 3 + 7.5); }
    if (hilos.outSh) { ctx.textAlign = 'left'; ctx.fillText(hilos.outSh, x + 25, peBoxY - 3 + 7.5); }
}

function drawPLC(loop, x, y) {
    const category = loop.instCategory || 'STD';
    const w = 340; // Widened from 320 to 340 (approx 6%) to avoid hilo overlap
    let h = 200;
    if (category === 'VALVE' || category === 'MOTOR') h = 260;

    ctx.strokeStyle = CONFIG.colors.line;
    ctx.lineWidth = 2;
    ctx.strokeRect(x - w / 2 + 10, y - h / 2, w - 10, h);

    ctx.font = CONFIG.fonts.tag;
    ctx.textAlign = 'center';
    ctx.fillText(loop.plcTag, x, y - h / 2 - 10);

    const termX = x - w / 2 + 55; // Re-adjusted right to leave space for longer hilos
    const termW = 35;
    const termCount = category === 'STD' ? 2 : (category === '3W' ? 3 : (category === 'VALVE' ? 6 : 8));
    const startY = y - ((termCount - 1) * 20) / 2;

    ctx.fillStyle = CONFIG.colors.text;
    ctx.font = CONFIG.fonts.small;
    ctx.fillText(loop.plcModule || '', termX + termW / 2, startY - 20);


    if (!loop.plcTerms) {
        loop.plcTerms = [loop.plcTermPos || '1', loop.plcTermNeg || '2', '3', '4', '5', '6', '7', '8'];
    }

    for (let i = 0; i < termCount; i++) {
        const ty = startY + (i * 20) - 7.5;
        drawTermSquare(termX, ty, loop.plcTerms[i] || (i + 1).toString(), termW);

        // Draw PLC Hilos (wire tags) to the LEFT of terminals - v2.1.3 fix
        const hilos = loop.plcHilos || {};
        const hTag = hilos[`h${i + 1}`];
        if (hTag) {
            ctx.fillStyle = CONFIG.colors.wireText;
            ctx.font = CONFIG.fonts.wire;
            ctx.textAlign = 'right';
            ctx.fillText(hTag, termX - 3, ty + 4.5); // Aligned with other boxes (ty is top, +7.5 is center, -3 is above line)
        }
    }

    const peY = startY + (termCount * 20);
    drawTermSquare(termX, peY - 7.5, loop.plcTermPe || 'PE', termW);
    drawGroundSymbol(termX + termW / 2, peY + 7.5);

    // Draw Shield Hilo for PLC to the LEFT
    const hilos = loop.plcHilos || {};
    if (hilos.hPe) {
        ctx.fillStyle = CONFIG.colors.wireText;
        ctx.font = CONFIG.fonts.wire;
        ctx.textAlign = 'right';
        ctx.fillText(hilos.hPe, termX - 3, peY - 3); // peY is the line center
    }

    // Right side: TAG label + signal names for VALVE/MOTOR, or plcDetails for others
    const labelX = x - w / 2 + 100; // Shifted right to match wider box and moved terminals
    const signalNames = loop.signalNames || [];
    const sigGroups = (category === 'VALVE') ? 3 : (category === 'MOTOR' ? 4 : 1);

    ctx.textAlign = 'left';
    ctx.fillStyle = CONFIG.colors.text;

    // Position TAG slightly higher to leave room for SIG1 in STD/3W
    const tagYOffset = (sigGroups === 1) ? 22 : 30;
    ctx.font = 'bold 11px "Consolas", monospace';
    ctx.fillText('TAG: ' + (loop.instTag || ''), labelX, y - h / 2 + tagYOffset);

    ctx.font = '10px "Consolas", monospace';
    // If VALVE/MOTOR, stack signal descriptions as a clean list from a fixed top position
    if (sigGroups > 1) {
        let sy = y - h / 2 + 55; // Start offset below TAG
        for (let g = 0; g < sigGroups; g++) {
            const label = signalNames[g] || `SIG${g + 1}`;
            ctx.fillText(label, labelX, sy);
            sy += 18; // Spacing between signal names
        }
    } else {
        // Standard behavior for STD / 3W (one signal centered between pairs)
        for (let g = 0; g < sigGroups; g++) {
            const pairTop = startY + (g * 2) * 20;
            const pairBot = startY + (g * 2 + 1) * 20;
            let pairCy = (pairTop + pairBot) / 2 + 4;
            const label = signalNames[g] || `SIG${g + 1}`;
            ctx.fillText(label, labelX, pairCy);
        }
    }

    if (sigGroups === 1) {
        // Show detail lines below SIG1
        ctx.font = '11px "Consolas", monospace';
        const lines = (loop.plcDetails || '').split('\n').filter(l => l.trim() !== '');
        let ly = startY + 40; // Below SIG1
        lines.forEach(l => {
            ctx.fillText(l, labelX, ly);
            ly += 16;
        });
    }
}

// ── Cable drawing ──────────────────────────────────────────────────────────────
function drawCable(x1, x2, y, opts, type, loop, wireMap) {
    const tag = opts.tag || '';
    const sec = opts.sec || '';
    const sh = opts.sh || false;
    const arm = opts.arm || false;
    const isDup = opts.isDup || false;

    let sx = x1, dx = x2;
    if (type === 'INST-JB') { sx = x1 + 45; dx = x2 - 20; }
    else if (type === 'INST-MARSH') { sx = x1 + 45; dx = x2 - 20; }
    else if (type === 'INST-PLC') { sx = x1 + 45; dx = x2 - 115; }
    else if (type === 'JB-MARSH') { sx = x1 + 20; dx = x2 - 20; }
    else if (type === 'JB-PLC') { sx = x1 + 20; dx = x2 - 115; }
    else if (type === 'MARSH-PLC') { sx = x1 + 20; dx = x2 - 115; }

    const gapSide = type.endsWith('PLC') ? 85 : 80;
    // Don't draw the mini vertical branch numbers on the box sides if we're rendering them inside the box already!
    // For INST side, yes. For PLC side, yes.
    const csx = sx + (type.startsWith('INST') ? 22 : gapSide);
    const cex = dx - gapSide;

    ctx.lineWidth = 3; // Triple thickness for the main trunk to make it stand out more
    ctx.strokeStyle = CONFIG.colors.cable; // Use cable color for main line

    // Main line
    ctx.beginPath(); ctx.moveTo(csx, y); ctx.lineTo(cex, y); ctx.stroke();

    ctx.lineWidth = 1; // Back to 1 for individual wires

    // Fan out
    const category = loop.instCategory || 'STD';
    const tCount = category === 'STD' ? 2 : (category === '3W' ? 3 : (category === 'VALVE' ? 6 : 8));
    const startY_local = y - ((tCount - 1) * 20) / 2;

    const baseTag = tag.trim().toUpperCase();
    let wireStart = 1;
    if (wireMap) {
        if (wireMap[baseTag]) wireStart = wireMap[baseTag] + 1;
    }

    for (let i = 0; i < tCount; i++) {
        const wireNum = wireStart + i;
        const wy = startY_local + (i * 20);
        ctx.beginPath(); ctx.moveTo(sx, wy); ctx.lineTo(csx, wy); ctx.lineTo(csx, y + (i < tCount / 2 ? -2 : 2)); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(cex, y + (i < tCount / 2 ? -2 : 2)); ctx.lineTo(cex, wy);
        // Wires finish exactly at dx
        ctx.lineTo(dx, wy);
        ctx.stroke();
        ctx.fillStyle = CONFIG.colors.wireText;
        ctx.font = CONFIG.fonts.wire;
        /* v2.1.3: Removed redundant wire numbers at instrument/PLC as per user request
        if (type.startsWith('INST')) {
            ctx.textAlign = 'left';
            ctx.fillText(wireNum, csx + 5, wy - 3);
        }
        */
        // v2.1.3: Removed redundant wire numbers outside PLC as per user request
        /*
        if (type.endsWith('PLC')) {
            ctx.textAlign = 'right';
            ctx.fillText(wireNum, cex - 5, wy - 3);
        }
        */
    }

    if (wireMap) {
        wireMap[baseTag] = wireStart + tCount - 1;
    }

    if (sh) {
        const shieldRY = 20;
        ctx.beginPath(); ctx.fillStyle = CONFIG.colors.bg; ctx.strokeStyle = CONFIG.colors.shield;
        ctx.ellipse((csx + cex) / 2, y, 7, shieldRY, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();

        // Target side connection (to component entrance)
        if (type.endsWith('JB') || type.endsWith('MARSH') || type.endsWith('PLC')) {
            const tTermCount = category === 'STD' ? 2 : (category === '3W' ? 3 : (category === 'VALVE' ? 6 : 8));
            const tStartTermY = y - ((tTermCount - 1) * 20) / 2;
            let sey = tStartTermY + (tTermCount * 20);

            // PE Border logic (Do NOT enter the box)
            let targetX = dx;
            if (type.endsWith('JB') || type.endsWith('MARSH')) {
                sey += 12.5; // Center of PE box vertically
                targetX = x2 - 20; // Edge of the 40w box
            } else if (type.endsWith('PLC')) {
                targetX = x2 - 170 + 55; // Updated for w=340 and termX offset
                // cex for PLC is dx - 85 = (x2 - 110) - 85 = x2 - 195. Edge is x2 - 170.
            }

            ctx.save();
            ctx.strokeStyle = CONFIG.colors.shield;
            ctx.lineWidth = 1;
            ctx.setLineDash([5, 4]);
            ctx.beginPath(); ctx.moveTo(cex, y); ctx.lineTo(cex, sey);
            ctx.lineTo(targetX, sey);
            ctx.stroke();
            ctx.setLineDash([]);
            ctx.restore();
        }

        // Source side connection (from component exit - right side of boxes)
        if (type.startsWith('JB') || type.startsWith('MARSH')) {
            const sTermCount = category === 'STD' ? 2 : (category === '3W' ? 3 : (category === 'VALVE' ? 6 : 8));
            const sStartTermY = y - ((sTermCount - 1) * 20) / 2;
            let ssy = sStartTermY + (sTermCount * 20) + 12.5; // Center of PE box vertically

            ctx.save();
            ctx.strokeStyle = CONFIG.colors.shield;
            ctx.lineWidth = 1;
            ctx.setLineDash([5, 4]);
            ctx.beginPath(); ctx.moveTo(csx, y); ctx.lineTo(csx, ssy); ctx.lineTo(x1 + 20, ssy); ctx.stroke();
            ctx.restore();
        }
    }

    ctx.fillStyle = isDup ? '#ff5555' : CONFIG.colors.text;
    ctx.font = CONFIG.fonts.cableTag; ctx.textAlign = 'center';
    ctx.fillText(tag, (csx + cex) / 2, y - 42);
    ctx.fillStyle = CONFIG.colors.text; ctx.font = CONFIG.fonts.label;
    ctx.fillText(sec, (csx + cex) / 2, y + 80);
    if (arm) ctx.fillText("(ARM)", (csx + cex) / 2, y + 92);
}

// ── Ground symbol ──────────────────────────────────────────────────────────────
function drawGroundSymbol(x, y) {
    // y = bottom edge of PE terminal (connection point)
    const stemLen = 10;
    const symY = y + stemLen;

    ctx.lineWidth = 1.5;
    ctx.strokeStyle = CONFIG.colors.shield;

    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x, symY);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(x - 8, symY); ctx.lineTo(x + 8, symY);
    ctx.moveTo(x - 5, symY + 3); ctx.lineTo(x + 5, symY + 3);
    ctx.moveTo(x - 2, symY + 6); ctx.lineTo(x + 2, symY + 6);
    ctx.stroke();
}

// ── Save / Load ────────────────────────────────────────────────────────────────
function saveProject() {
    autoSaveToBrowser(); // This calls updateCurrentLoopFromUI()
    try {
        const dataStruct = {
            sheets,
            cableNamingMode,
            projectName,
            colors: CONFIG.colors,
            appVersion: "v2.1.4",
            exportDate: new Date().toISOString()
        };
        const dataString = JSON.stringify(dataStruct, null, 2);
        const blob = new Blob([dataString], { type: 'application/json;charset=utf-8' });

        const a = document.createElement('a');
        const cleanName = (projectName || 'proyecto_lazos').replace(/[^a-z0-9_\-]/gi, '_');
        a.href = URL.createObjectURL(blob);
        a.download = cleanName + '.json';
        document.body.appendChild(a); // Required for some browsers
        a.click();
        document.body.removeChild(a);

        // Update path display with saved filename
        const pathEl = document.getElementById('projectPathDisplay');
        if (pathEl) pathEl.textContent = '💾 ' + a.download;
        localStorage.setItem('loopCAD_lastFile', '💾 ' + a.download);

        // Revoke to clean up memory
        setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    } catch (err) {
        console.error('Save Error:', err);
        alert('Error al guardar el archivo: ' + err.message);
    }
}

function loadProject(e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const content = e.target.result;
            if (!content || content.trim() === '') {
                throw new Error('El archivo está vacío');
            }

            const d = JSON.parse(content);

            // Validation of structure
            if (!d.sheets && !d.loops) {
                throw new Error('El archivo no contiene datos válidos de la aplicación (faltan hojas/lazos)');
            }

            // Support old format (single loops array) and new (sheets)
            if (d.sheets) {
                sheets = d.sheets;
            } else if (d.loops) {
                sheets = [d.loops];
            }

            if (d.cableNamingMode) cableNamingMode = d.cableNamingMode;
            if (d.projectName !== undefined) {
                projectName = d.projectName;
                document.getElementById('projectName').value = projectName;
            }

            if (d.colors) {
                CONFIG.colors = { ...CONFIG.colors, ...d.colors };
                if (document.getElementById('colorCableTag')) document.getElementById('colorCableTag').value = CONFIG.colors.cable;
                if (document.getElementById('colorWireText')) document.getElementById('colorWireText').value = CONFIG.colors.wireText;
                if (document.getElementById('colorShield')) document.getElementById('colorShield').value = CONFIG.colors.shield;
            }

            // Recalculate and reset
            currentSheetIndex = 0;
            currentLoopIndex = 0;

            buildLoopButtons();
            updateSheetUI();
            loadLoopToUI(0);
            renderScene();

            // Update path display with loaded filename
            const pathEl = document.getElementById('projectPathDisplay');
            if (pathEl) pathEl.textContent = '📂 ' + file.name;
            localStorage.setItem('loopCAD_lastFile', '📂 ' + file.name);

            alert('Proyecto cargado correctamente: ' + (projectName || 'Sin nombre'));

            // Clear input for next load
            e.target.value = '';
        } catch (err) {
            console.error('Load Error:', err);
            alert('ERROR: El archivo seleccionado no es válido o está corrupto.\n\nDetalles: ' + err.message);
            e.target.value = '';
        }
    };

    // Explicit UTF-8 reading
    reader.readAsText(file, 'UTF-8');
}

// ── ZIP Project Backup ────────────────────────────────────────────────────────
async function descargarZipProyecto() {
    if (typeof JSZip === 'undefined') {
        return alert('La librería JSZip no está cargada.');
    }
    const zip = new JSZip();
    try {
        // We include all essential project files
        const files = ['index.html', 'script.js', 'style.css'];
        for (const file of files) {
            // Append timestamp to prevent cached versions and ensure we get the latest saved code
            const resp = await fetch(file + '?t=' + Date.now());
            if (!resp.ok) throw new Error(`No se pudo leer ${file}: ${resp.statusText}`);
            const text = await resp.text();
            zip.file(file, text);
        }

        // Also include the current project state specifically as a JSON
        const projectData = JSON.stringify({
            sheets,
            cableNamingMode,
            projectName,
            colors: CONFIG.colors
        }, null, 2);
        zip.file('project_data_backup.json', projectData);

        const content = await zip.generateAsync({ type: 'blob' });

        // Generate a nice timestamp for the filename
        const now = new Date();
        const datePart = now.getFullYear() +
            String(now.getMonth() + 1).padStart(2, '0') +
            String(now.getDate()).padStart(2, '0');
        const timePart = String(now.getHours()).padStart(2, '0') +
            String(now.getMinutes()).padStart(2, '0');

        // Clean project name for valid filename
        const cleanName = (projectName || 'proyecto_lazos').replace(/[^a-z0-9]/gi, '_').toLowerCase();

        const a = document.createElement('a');
        a.href = URL.createObjectURL(content);
        a.download = `${cleanName}_backup_${datePart}_${timePart}.zip`;
        a.click();
    } catch (err) {
        console.error('ZIP Error:', err);
        alert('Error al generar el Backup ZIP: ' + err.message + '\n\nIMPORTANTE: Esta función requiere un servidor local para leer los archivos (ej: abrir con VS Code Live Server o http-server). Si abres el archivo directamente desde el explorador de Windows, el navegador bloqueará la lectura del código por seguridad.');
    }
}

// ── PDF Export ─────────────────────────────────────────────────────────────────
async function exportPDF() {
    if (!window.jspdf) return alert('Falta la librería PDF');
    const { jsPDF } = window.jspdf;
    // A3 Portrait (297x420mm) fits 8 loops (1400x2400 aspect ratio) much better
    const pdf = new jsPDF('p', 'mm', 'a3');
    const oldColors = { ...CONFIG.colors };
    const oldSheet = currentSheetIndex;

    // Force B&W for export
    CONFIG.colors = { bg: '#ffffff', text: '#000000', line: '#000000', cable: '#000000', wireText: '#000000', shield: '#000000', grid: '#ffffff' };

    for (let i = 0; i < sheets.length; i++) {
        currentSheetIndex = i;
        renderScene();
        await new Promise(r => setTimeout(r, 150)); // Wait for render
        const img = canvas.toDataURL('image/png');
        if (i > 0) pdf.addPage('a3', 'p');

        // A3 Portrait: 297x420mm. 
        // Logic: 400mm height (10mm margin top/bottom), calculate width based on aspect ratio
        const imgH = 400;
        const imgW = imgH * (canvas.width / canvas.height); // 400 * (1400/2400) = ~233mm
        const xPos = (297 - imgW) / 2; // Center horizontally

        pdf.addImage(img, 'PNG', xPos, 10, imgW, imgH);
    }

    pdf.save((projectName || 'diagramas_lazo') + '.pdf');
    currentSheetIndex = oldSheet;
    CONFIG.colors = oldColors;
    renderScene();
}

// ── DXF Export (all sheets) ────────────────────────────────────────────────────
function exportDXF(filename = 'loop_sheet.dxf') {
    updateCurrentLoopFromUI(); // Ensure data is synced

    const sheetH = CONFIG.canvasHeight;
    const TOTAL_H = sheets.length * sheetH;
    const W = CONFIG.canvasWidth;
    const cols = getCols();

    // ── DXF R12 format with HEADER for Spanish Encoding ────────────────────
    let dxf = `0\nSECTION\n2\nHEADER\n9\n$DWGCODEPAGE\n3\nANSI_1252\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n`;

    const globalFy = (v_absolute) => TOTAL_H - v_absolute;
    const DXF_COLOR = 7;

    const makeDxfHelpers = (offY) => {
        // Here v_local is relative to the top of the sheet (0 to sheetH)
        const fy = (v_local) => globalFy(offY + v_local);

        const line = (x1, y1, x2, y2, color = DXF_COLOR) => {
            dxf += `0\nLINE\n8\n0\n62\n${color}\n10\n${x1.toFixed(2)}\n20\n${fy(y1).toFixed(2)}\n11\n${x2.toFixed(2)}\n21\n${fy(y2).toFixed(2)}\n`;
        };

        const dashedLine = (x1, y1, x2, y2, color = DXF_COLOR) => {
            const ddx = x2 - x1, ddy = y2 - y1;
            const len = Math.sqrt(ddx * ddx + ddy * ddy);
            if (len === 0) return;
            const dashLen = 10, gapLen = 6, total = dashLen + gapLen;
            const steps = Math.floor(len / total);
            const nx = ddx / len, ny = ddy / len;
            for (let i = 0; i <= steps; i++) {
                const start = i * total;
                const sx = x1 + nx * start, sy = y1 + ny * start;
                const endPos = Math.min(len, start + dashLen);
                const ex2 = x1 + nx * endPos, ey2 = y1 + ny * endPos;
                dxf += `0\nLINE\n8\n0\n62\n${color}\n10\n${sx.toFixed(2)}\n20\n${fy(sy).toFixed(2)}\n11\n${ex2.toFixed(2)}\n21\n${fy(ey2).toFixed(2)}\n`;
            }
        };

        const circle = (x, y, r, color = DXF_COLOR) => {
            dxf += `0\nCIRCLE\n8\n0\n62\n${color}\n10\n${x.toFixed(2)}\n20\n${fy(y).toFixed(2)}\n40\n${r.toFixed(2)}\n`;
        };

        const ellipse = (x, y, rx, ry, color = DXF_COLOR) => {
            const steps = 36;
            for (let i = 0; i < steps; i++) {
                const a1 = (i / steps) * Math.PI * 2, a2 = ((i + 1) / steps) * Math.PI * 2;
                line(x + rx * Math.cos(a1), y + ry * Math.sin(a1), x + rx * Math.cos(a2), y + ry * Math.sin(a2), color);
            }
        };

        const text = (x, y, txt, h = 10, align = 'center', color = DXF_COLOR) => {
            if (!txt) return;
            // Clean up text: remove newlines, specific symbols, and replace accented characters
            let clean = String(txt).replace(/[\r\n]/g, ' ').replace(/²/g, '2');

            // Spanish accent removal for DXF compatibility
            clean = clean.normalize("NFD")
                .replace(/[\u0300-\u036f]/g, "") // Remove accents
                .replace(/ñ/g, "n").replace(/Ñ/g, "N") // Replace ñ
                .replace(/[^\x00-\x7F]/g, ""); // Remove any other non-ASCII chars

            const xs = x.toFixed(2), ys = fy(y).toFixed(2);
            dxf += `0\nTEXT\n8\n0\n62\n${color}\n10\n${xs}\n20\n${ys}\n40\n${h.toFixed(2)}\n1\n${clean}\n`;
            if (align === 'center') dxf += `72\n1\n11\n${xs}\n21\n${ys}\n`;
            else if (align === 'right') dxf += `72\n2\n11\n${xs}\n21\n${ys}\n`;
        };

        const drawSq = (x, y, tt, w = 15) => {
            line(x, y, x + w, y);
            line(x + w, y, x + w, y + 15);
            line(x + w, y + 15, x, y + 15);
            line(x, y + 15, x, y);
            text(x + w / 2, y + 11, tt, 6, 'center');
        };

        const ground = (x, y) => {
            line(x, y, x, y + 10);
            line(x - 8, y + 10, x + 8, y + 10);
            line(x - 5, y + 13, x + 5, y + 13);
            line(x - 2, y + 16, x + 2, y + 16);
        };

        return { line, dashedLine, circle, ellipse, text, drawSq, ground };
    };

    const cableWireMap = {};

    sheets.forEach((sheetLoops, sIdx) => {
        const offY = sIdx * sheetH;
        // makeDxfHelpers expects offY to know where the sheet starts in global space
        const { line, dashedLine, circle, ellipse, text, drawSq, ground } = makeDxfHelpers(offY);

        // Header Table - relative to sheet (0, 40, 80)
        line(0, 0, W, 0);
        line(0, 80, W, 80);
        line(0, 0, 0, sheetH);
        line(W, 0, W, sheetH);
        line(0, 40, W, 40);

        const splitX = W * 0.45;
        line(splitX, 0, splitX, 80);

        text(10, 25, `PROYECTO: ${projectName}`, 10, 'left');
        text(splitX / 2 - 80, 25, `CAMPO - Hoja ${sIdx + 1}`, 12, 'center');
        text(splitX + 20, 25, 'EDIFICIO DE CONTROL', 12, 'left');

        text(cols.inst, 70, 'INSTRUMENTO', 10, 'center');
        text(cols.jb, 70, 'CAJA DE AGRUPACION', 10, 'center');
        text(cols.marsh, 70, 'MARSHALING', 10, 'center');
        text(cols.plc, 70, 'ARMARIO DE CONTROL', 10, 'center');

        let cCount = getGlobalCableCount(sIdx);
        sheetLoops.forEach((loop, i) => {
            const y = 240 + (i * 350); // LOCAL coordinate inside sheet

            line(0, y + 175, W, y + 175);
            text(15, y + 5, (i + 1).toString(), 20);

            if (!loop.instTag || loop.instTag.trim() === '') return;

            const category = loop.instCategory || 'STD';
            const tCount = category === 'STD' ? 2 : (category === '3W' ? 3 : (category === 'VALVE' ? 6 : 8));
            const cNames = buildCableNames(loop, cCount, (n) => { cCount = n; });
            const ix = cols.inst, jx = cols.jb, mx = cols.marsh, px = cols.plc;

            // Instrument
            circle(ix, y, 30);
            const fullTag = (loop.instTag || '').trim();
            if (fullTag.length > 0) {
                line(ix - 30, y, ix + 30, y);
                const hyphenIndex = fullTag.indexOf('-');
                let p1 = fullTag, p2 = '';
                if (hyphenIndex !== -1) {
                    p1 = fullTag.substring(0, hyphenIndex);
                    p2 = fullTag.substring(hyphenIndex + 1);
                }
                let h1 = p1.length > 10 ? Math.floor(10 * (10 / p1.length)) : 10;
                text(ix, p2 ? y - 10 : y - 2, p1, h1, 'center');
                if (p2) {
                    let h2 = p2.length > 10 ? Math.floor(10 * (10 / p2.length)) : 10;
                    text(ix, y + 12, p2, h2, 'center');
                }
            }
            text(ix, y + 45, loop.instType, 8, 'center');

            const itx = ix + 40;
            line(ix + 30, y - 5, itx, y - 5);
            line(ix + 30, y + 5, itx, y + 5);

            const sTermYI = y - ((tCount - 1) * 20) / 2;
            for (let j = 0; j < tCount; j++) {
                const ty = sTermYI + (j * 20);
                drawSq(itx, ty - 7.5, loop.instTerms ? loop.instTerms[j] : (j + 1).toString(), 15);
                const hilos = loop.instHilos || [];
                const hTag = hilos[j];
                if (hTag) text(itx + 18, ty - 3, hTag, 7.5, 'left');
            }

            // JB
            if (loop.jbEnabled) {
                const jh = tCount * 20 + 115;
                const jw = 160;
                const jTop = y - jh / 2;
                line(jx - jw / 2, jTop, jx + jw / 2, jTop); line(jx + jw / 2, jTop, jx + jw / 2, jTop + jh);
                line(jx + jw / 2, jTop + jh, jx - jw / 2, jTop + jh); line(jx - jw / 2, jTop + jh, jx - jw / 2, jTop);
                // Box Tag exactly above the box
                text(jx, jTop - 12, (loop.jbTag || "JB-TAG").toUpperCase(), 14, 'center');
                text(jx, jTop + 15, (loop.jbModule || "X1").toUpperCase(), 10, 'center'); line(jx - jw / 2, jTop + 25, jx + jw / 2, jTop + 25);

                const sTermYJ = y - ((tCount - 1) * 20) / 2;
                for (let j = 0; j < tCount; j++) {
                    const ty = sTermYJ + (j * 20);
                    drawSq(jx - 20, ty - 7.5, (loop.jbTerms && loop.jbTerms[j]) || (j + 1).toString(), 40);
                    const hilos = loop.jbHilos || {};
                    const instH = loop.instHilos || [];
                    if (j === 0) {
                        const hIn = hilos.inPos || instH[0], hOut = hilos.outPos || instH[0];
                        if (hIn) text(jx - 25, ty - 3, hIn, 7.5, 'right');
                        if (hOut) text(jx + 25, ty - 3, hOut, 7.5, 'left');
                    } else if (j === 1) {
                        const hIn = hilos.inNeg || instH[1], hOut = hilos.outNeg || instH[1];
                        if (hIn) text(jx - 25, ty - 3, hIn, 7.5, 'right');
                        if (hOut) text(jx + 25, ty - 3, hOut, 7.5, 'left');
                    } else {
                        const hTag = instH[j] || '';
                        if (hTag) { text(jx - 25, ty - 3, hTag, 7.5, 'right'); text(jx + 25, ty - 3, hTag, 7.5, 'left'); }
                    }
                }
                const peLineY = sTermYJ + (tCount * 20);
                const peBoxY = peLineY + 5;
                drawSq(jx - 20, peBoxY, loop.jbTermSh || 'PE', 40);
                ground(jx, peBoxY + 15);
                const hilos = loop.jbHilos || {};
                if (hilos.inSh) text(jx - 35, peBoxY - 3, hilos.inSh, 7.5, 'right');
                if (hilos.outSh) text(jx + 35, peBoxY - 3, hilos.outSh, 7.5, 'left');
            }

            // Marshalling
            if (loop.marshEnabled) {
                const mh = tCount * 20 + 120;
                const mw = 160;
                const mTop = y - mh / 2;
                line(mx - mw / 2, mTop, mx + mw / 2, mTop); line(mx + mw / 2, mTop, mx + mw / 2, mTop + mh);
                line(mx + mw / 2, mTop + mh, mx - mw / 2, mTop + mh); line(mx - mw / 2, mTop + mh, mx - mw / 2, mTop);
                // Marsh Tag exactly above the box
                text(mx, mTop - 12, (loop.marshTag || "MARSH-TAG").toUpperCase(), 14, 'center');
                text(mx, mTop + 15, (loop.marshModule || "X1").toUpperCase(), 10, 'center'); line(mx - mw / 2, mTop + 25, mx + mw / 2, mTop + 25);

                const sTermYM = y - ((tCount - 1) * 20) / 2;
                for (let j = 0; j < tCount; j++) {
                    const ty = sTermYM + (j * 20);
                    drawSq(mx - 20, ty - 7.5, (loop.marshTerms && loop.marshTerms[j]) || (j + 1).toString(), 40);
                    const hilos = loop.marshHilos || {}, instH = loop.instHilos || [];
                    if (j === 0) {
                        const hIn = hilos.inPos || instH[0], hOut = hilos.outPos || instH[0];
                        if (hIn) text(mx - 25, ty - 3, hIn, 7.5, 'right');
                        if (hOut) text(mx + 25, ty - 3, hOut, 7.5, 'left');
                    } else if (j === 1) {
                        const hIn = hilos.inNeg || instH[1], hOut = hilos.outNeg || instH[1];
                        if (hIn) text(mx - 25, ty - 3, hIn, 7.5, 'right');
                        if (hOut) text(mx + 25, ty - 3, hOut, 7.5, 'left');
                    } else {
                        const hTag = instH[j] || '';
                        if (hTag) { text(mx - 25, ty - 3, hTag, 7.5, 'right'); text(mx + 25, ty - 3, hTag, 7.5, 'left'); }
                    }
                }
                const peLineY = sTermYM + (tCount * 20);
                const peBoxY = peLineY + 5;
                drawSq(mx - 20, peBoxY, loop.marshTermInSh || 'PE', 40);
                ground(mx, peBoxY + 15);
                const hilos = loop.marshHilos || {};
                if (hilos.inSh) text(mx - 35, peBoxY - 3, hilos.inSh, 7.5, 'right');
                if (hilos.outSh) text(mx + 35, peBoxY - 3, hilos.outSh, 7.5, 'left');
            }

            // PLC
            let ph = (category === 'VALVE' || category === 'MOTOR') ? 260 : 200, pw = 340;
            const pcx = px;
            line(pcx - pw / 2, y - ph / 2, pcx + pw / 2, y - ph / 2);
            line(pcx + pw / 2, y - ph / 2, pcx + pw / 2, y + ph / 2);
            line(pcx + pw / 2, y + ph / 2, pcx - pw / 2, y + ph / 2);
            line(pcx - pw / 2, y + ph / 2, pcx - pw / 2, y - ph / 2);
            text(pcx, y - ph / 2 - 10, loop.plcTag, 10, 'center');

            const termX = pcx - pw / 2 + 55, ptw = 35;
            const sTermYP = y - ((tCount - 1) * 20) / 2;
            text(termX + ptw / 2, sTermYP - 20, loop.plcModule || '', 9, 'center');
            for (let j = 0; j < tCount; j++) {
                const ty = sTermYP + (j * 20);
                drawSq(termX, ty - 7.5, (loop.plcTerms && loop.plcTerms[j]) || (j + 1).toString(), ptw);
                const hilos = loop.plcHilos || {}, hTag = hilos[`h${j + 1}`];
                if (hTag) text(termX - 3, ty - 3, hTag, 7.5, 'right');
            }
            const pey = sTermYP + (tCount * 20);
            drawSq(termX, pey - 7.5, loop.plcTermPe || 'PE', ptw);
            ground(termX + ptw / 2, pey + 7.5);
            const hilosPe = loop.plcHilos || {};
            if (hilosPe.hPe) text(termX - 3, pey - 3, hilosPe.hPe, 7.5, 'right');

            const signalNames = loop.signalNames || [];
            const sigCount = (category === 'VALVE') ? 3 : (category === 'MOTOR' ? 4 : 1);
            const labelX = pcx - pw / 2 + 100;
            text(labelX, y - ph / 2 + (sigCount === 1 ? 22 : 30), 'TAG: ' + (loop.instTag || ''), 10, 'left');
            for (let g = 0; g < sigCount; g++) {
                const label = signalNames[g] || `SIG${g + 1}`;
                if (label) text(labelX, (sigCount > 1 ? (y - ph / 2 + 55 + g * 18) : (sTermYP + 13.5)), label, 8.5, 'left');
            }
            if (sigCount === 1) {
                const dets = (loop.plcDetails || '').split('\n').filter(l => l.trim() !== '');
                let dy = sTermYP + 40;
                dets.forEach(dl => { text(labelX, dy, dl, 8, 'left'); dy += 16; });
            }

            // Cables
            const drawCab = (tag_in, specs, sh, arm, ct) => {
                let sx, dx;
                if (ct === 'INST-JB') { sx = ix + 55; dx = jx - 20; }
                else if (ct === 'INST-MARSH') { sx = ix + 55; dx = mx - 20; }
                else if (ct === 'INST-PLC') { sx = ix + 55; dx = px - 115; }
                else if (ct === 'JB-MARSH') { sx = jx + 20; dx = mx - 20; }
                else if (ct === 'JB-PLC') { sx = jx + 20; dx = px - 115; }
                else if (ct === 'MARSH-PLC') { sx = mx + 20; dx = px - 115; }

                const gapSide = ct.endsWith('PLC') ? 85 : 80;
                const csx = sx + (ct.startsWith('INST') ? 22 : gapSide);
                const cex = dx - gapSide;

                for (let k = -2; k <= 2; k++) line(csx, y + k * 0.3, cex, y + k * 0.3); // Trunk
                const csy = y - ((tCount - 1) * 20) / 2;
                const baseTag = (tag_in || '').trim().toUpperCase();
                let wireStart = cableWireMap[baseTag] ? cableWireMap[baseTag] + 1 : 1;

                for (let j = 0; j < tCount; j++) {
                    const wy = csy + (j * 20);
                    line(sx, wy, csx, wy); line(csx, wy, csx, y + (j < tCount / 2 ? -2 : 2));
                    line(cex, y + (j < tCount / 2 ? -2 : 2), cex, wy); line(cex, wy, dx, wy);
                }
                cableWireMap[baseTag] = wireStart + tCount - 1;

                if (sh) {
                    ellipse((csx + cex) / 2, y, 7, 20);
                    if (ct.endsWith('JB') || ct.endsWith('MARSH') || ct.endsWith('PLC')) {
                        let sey = csy + (tCount * 20), targetX = (ct.endsWith('PLC') ? px - 115 : dx);
                        if (ct.endsWith('JB') || ct.endsWith('MARSH')) sey += 12.5;
                        dashedLine(cex, y, cex, sey); dashedLine(cex, sey, targetX, sey);
                    }
                    if (ct.startsWith('JB') || ct.startsWith('MARSH')) {
                        let sy2 = csy + (tCount * 20), targetX = (ct.startsWith('JB') ? jx + 20 : mx + 20);
                        sy2 += 12.5; dashedLine(csx, y, csx, sy2); dashedLine(csx, sy2, targetX, sy2);
                    }
                }
                text((csx + cex) / 2, y - 35, tag_in, 8.5, 'center');
                text((csx + cex) / 2, y + 35, specs, 7, 'center');
                if (arm) text((csx + cex) / 2, y + 45, '(ARM)', 6, 'center');
            };

            let currentComp = 'INST';
            if (loop.jbEnabled) { drawCab(cNames.c1, loop.cable1Section, loop.cable1Shield, loop.cable1Armor, 'INST-JB'); currentComp = 'JB'; }
            if (loop.marshEnabled) {
                const sTag = (currentComp === 'INST' ? cNames.c1 : cNames.c2), sType = (currentComp === 'INST' ? 'INST-MARSH' : 'JB-MARSH');
                const sSec = (currentComp === 'INST' ? loop.cable1Section : loop.cable2Section);
                const sSh = (currentComp === 'INST' ? loop.cable1Shield : loop.cable2Shield), sAr = (currentComp === 'INST' ? loop.cable1Armor : loop.cable2Armor);
                drawCab(sTag, sSec, sSh, sAr, sType); currentComp = 'MARSH';
            }
            const fTag = (currentComp === 'MARSH' ? cNames.c3 : (currentComp === 'JB' ? cNames.c2 : cNames.c1));
            const fType = (currentComp === 'MARSH' ? 'MARSH-PLC' : (currentComp === 'JB' ? 'JB-PLC' : 'INST-PLC'));
            const fSec = (currentComp === 'MARSH' ? loop.cableSysSection : (currentComp === 'JB' ? loop.cable2Section : loop.cable1Section));
            const fSh = (currentComp === 'MARSH' ? loop.cableSysShield : (currentComp === 'JB' ? loop.cable2Shield : loop.cable1Shield));
            const fAr = (currentComp === 'MARSH' ? loop.cableSysArmor : (currentComp === 'JB' ? loop.cable2Armor : loop.cable1Armor));
            drawCab(fTag, fSec, fSh, fAr, fType);
        });
    });

    dxf += `0\nENDSEC\n0\nEOF\n`;
    const blob = new Blob([dxf], { type: 'application/dxf' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; a.click();
}




async function uploadToGitHub() {
    const token = prompt("Por favor, introduce tu GitHub Personal Access Token (PAT) con permisos de 'repo':");
    if (!token) return;

    const repoName = prompt("Introduce el nombre para el repositorio:", (projectName || "loop-diagram-generator").replace(/\s+/g, '-').toLowerCase());
    if (!repoName) return;

    const headers = {
        'Authorization': `token ${token}`,
        'Accept': 'application/vnd.github.v3+json',
        'Content-Type': 'application/json'
    };

    try {
        // 1. Check if user exists and create Repo
        const userRes = await fetch('https://api.github.com/user', { headers });
        if (!userRes.ok) throw new Error("Token inválido o error de conexión.");
        const userData = await userRes.json();
        const username = userData.login;

        let repoRes = await fetch(`https://api.github.com/user/repos`, {
            method: 'POST',
            headers,
            body: JSON.stringify({ name: repoName, private: false })
        });

        if (repoRes.status !== 201 && repoRes.status !== 422) {
            throw new Error("Error al crear el repositorio.");
        }

        alert(`Repositorio '${repoName}' listo. Subiendo archivos (index.html, script.js, style.css)...`);

        const files = ['index.html', 'script.js', 'style.css'];
        for (const fileName of files) {
            try {
                const fileResp = await fetch(fileName);
                if (!fileResp.ok) throw new Error(`No se pudo leer localmente ${fileName}. Asegúrate de estar ejecutando la app desde un servidor (ej: http-server).`);
                const content = await fileResp.text();
                // Base64 encoding that handles UTF-8 correctly
                const base64Content = btoa(unescape(encodeURIComponent(content)));

                const fileUrl = `https://api.github.com/repos/${username}/${repoName}/contents/${fileName}`;
                const checkFile = await fetch(fileUrl, { headers });
                let sha = null;
                if (checkFile.ok) {
                    const checkData = await checkFile.json();
                    sha = checkData.sha;
                }

                await fetch(fileUrl, {
                    method: 'PUT',
                    headers,
                    body: JSON.stringify({
                        message: `Upload ${fileName}`,
                        content: base64Content,
                        sha: sha
                    })
                });
            } catch (err) {
                console.error(`Error subiendo ${fileName}:`, err);
                alert(`Error subiendo ${fileName}: ${err.message}`);
            }
        }

        alert(`¡Éxito! Aplicación subida a: https://github.com/${username}/${repoName}`);
        window.open(`https://github.com/${username}/${repoName}`, '_blank');
    } catch (err) {
        console.error(err);
        alert("Integración con GitHub: " + err.message);
    }
}
async function downloadFromGitHub() {
    const token = prompt("Por favor, introduce tu GitHub Personal Access Token (PAT) con permisos de 'repo':");
    if (!token) return;

    const userRepo = prompt("Introduce el nombre de usuario y el repositorio (ej: usuario/repositorio):");
    if (!userRepo || !userRepo.includes('/')) return;

    const [username, repoName] = userRepo.split('/');
    const headers = {
        'Authorization': `token ${token}`,
        'Accept': 'application/vnd.github.v3+json'
    };

    try {
        const fileRes = await fetch(`https://api.github.com/repos/${username}/${repoName}/contents/project.json`, { headers });
        if (!fileRes.ok) throw new Error("No se pudo encontrar 'project.json' en el repositorio.");

        const fileData = await fileRes.json();
        const content = decodeURIComponent(escape(atob(fileData.content)));
        const data = JSON.parse(content);

        if (data.sheets) {
            sheets = data.sheets;
            cableNamingMode = data.cableNamingMode || 'TAG';
            projectName = data.projectName || '';
            if (data.colors) Object.assign(CONFIG.colors, data.colors);

            currentSheetIndex = 0;
            currentLoopIndex = 0;
            document.getElementById('projectName').value = projectName;
            buildLoopButtons();
            updateSheetUI();
            loadLoopToUI(0);
            renderScene();
            alert("Proyecto descargado correctamente desde GitHub.");
        }
    } catch (err) {
        console.error(err);
        alert("Error al descargar de GitHub: " + err.message);
    }
}

// ── Cable List ────────────────────────────────────────────────────────────────
function showCableList() {
    const sumTotals = {}; // { section: totalLength }
    const cableDetails = []; // [{ loop, tag, type, origin, dest, len }]
    const processedTags = new Set(); // To prevent duplicates in the list

    sheets.forEach((sheet, sIdx) => {
        let sheetCableCount = 1; // RESET COUNT PER SHEET TO MATCH DIAGRAM
        sheet.forEach((loop, lIdx) => {
            const hasData = (loop.instTag && loop.instTag.trim() !== '') ||
                (loop.jbEnabled && loop.jbTag && loop.jbTag.trim() !== '') ||
                (loop.marshEnabled && loop.marshTag && loop.marshTag.trim() !== '');

            if (!hasData) return;

            const cNames = buildCableNames(loop, sheetCableCount, (n) => { sheetCableCount = n; });
            const loopTag = (loop.instTag && loop.instTag.trim() !== '') ? loop.instTag : `Lazo ${lIdx + 1}`;

            const addCable = (tag, type, origin, dest, len) => {
                if (!tag || tag === 'N/A' || processedTags.has(tag)) return;
                processedTags.add(tag);

                const l = parseFloat(len) || 0;
                cableDetails.push({
                    loopTag: loopTag,
                    tag: tag,
                    type: type || 'S/D',
                    origin: origin || 'S/D',
                    dest: dest || 'S/D',
                    length: l
                });
                if (l > 0) {
                    const sec = (type || 'S/D').trim();
                    sumTotals[sec] = (sumTotals[sec] || 0) + l;
                }
            };

            // Cable 1
            let c1Origin = loopTag;
            let c1Dest = loop.jbEnabled ? loop.jbTag : (loop.marshEnabled ? loop.marshTag : loop.plcTag);
            addCable(cNames.c1, loop.cable1Section, c1Origin, c1Dest, loop.cable1Len);

            // Cable 2
            if (loop.jbEnabled) {
                let c2Origin = loop.jbTag;
                let c2Dest = loop.marshEnabled ? loop.marshTag : loop.plcTag;
                addCable(cNames.c2, loop.cable2Section, c2Origin, c2Dest, loop.cable2Len);
            }

            // Cable 3 (System)
            if (loop.marshEnabled) {
                let c3Origin = loop.marshTag;
                let c3Dest = loop.plcTag;
                addCable(cNames.c3, loop.cableSysSection, c3Origin, c3Dest, loop.cableSysLen);
            }
        });
    });

    // Populate Detailed Table
    const tbodyDetail = document.querySelector('#cableTableNew tbody');
    if (tbodyDetail) {
        tbodyDetail.innerHTML = '';
        cableDetails.forEach(c => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${c.loopTag}</td>
                <td>${c.tag}</td>
                <td>${c.type}</td>
                <td>${c.origin}</td>
                <td>${c.dest}</td>
                <td style="text-align:right;">${c.length.toFixed(1)} m</td>
            `;
            tbodyDetail.appendChild(tr);
        });
    }

    // Populate Summary Table
    const tbodySum = document.querySelector('#summaryTableNew tbody');
    tbodySum.innerHTML = '';
    const sections = Object.keys(sumTotals).sort();
    if (sections.length === 0) {
        tbodySum.innerHTML = '<tr><td colspan="2" style="text-align:center;">No hay cables con longitud definida > 0.</td></tr>';
    } else {
        sections.forEach(s => {
            const tr = document.createElement('tr');
            tr.innerHTML = `<td>${s}</td><td style="text-align:right;"><strong>${sumTotals[s].toFixed(2)} m</strong></td>`;
            tbodySum.appendChild(tr);
        });
    }

    document.getElementById('cableListView').classList.add('active');
}

function exportCableList() {
    const list = [];
    const processedTags = new Set();

    sheets.forEach((sheet, sIdx) => {
        let sheetCableCount = 1;
        sheet.forEach((loop, lIdx) => {
            const hasData = (loop.instTag && loop.instTag.trim() !== '') ||
                (loop.jbEnabled && loop.jbTag && loop.jbTag.trim() !== '') ||
                (loop.marshEnabled && loop.marshTag && loop.marshTag.trim() !== '');
            if (!hasData) return;

            const cNames = buildCableNames(loop, sheetCableCount, (n) => { sheetCableCount = n; });
            const loopTag = (loop.instTag && loop.instTag.trim() !== '') ? loop.instTag : `Lazo ${lIdx + 1}`;

            const pushCable = (tag, type, origin, dest, len) => {
                if (!tag || tag === 'N/A' || processedTags.has(tag)) return;
                processedTags.add(tag);
                list.push([loopTag, tag, type || 'S/D', origin || 'S/D', dest || 'S/D', parseFloat(len) || 0]);
            };

            let c1Dest = loop.jbEnabled ? loop.jbTag : (loop.marshEnabled ? loop.marshTag : loop.plcTag);
            pushCable(cNames.c1, loop.cable1Section, loopTag, c1Dest, loop.cable1Len);

            if (loop.jbEnabled) {
                let c2Dest = loop.marshEnabled ? loop.marshTag : loop.plcTag;
                pushCable(cNames.c2, loop.cable2Section, loop.jbTag, c2Dest, loop.cable2Len);
            }
            if (loop.marshEnabled) {
                pushCable(cNames.c3, loop.cableSysSection, loop.marshTag, loop.plcTag, loop.cableSysLen);
            }
        });
    });

    // Forced sep=; for Excel column recognition
    let csv = "sep=;\n";
    csv += "Lazo;Tag Cable;Tipo;Origen;Destino;Metros\n";
    list.forEach(row => {
        // Use semicolon (;) for better compatibility with Excel
        // Sanitize '²' to '2' to prevent encoding issues (e.g. mmÂ²)
        csv += row.map(v => {
            let s = (v || '').toString();
            s = s.replace(/²/g, '2');
            return `"${s.replace(/"/g, '""')}"`;
        }).join(";") + "\n";
    });

    const totals = {};
    list.forEach(r => { if (r[5] > 0) totals[r[2]] = (totals[r[2]] || 0) + r[5]; });
    csv += "\nRESUMEN POR TIPOS\nTipo;Total(m)\n";
    Object.keys(totals).sort().forEach(s => {
        const cleanS = s.replace(/²/g, '2');
        csv += `"${cleanS}";${totals[s].toFixed(2)}\n`;
    });

    const blob = new Blob(["\ufeff" + csv], { type: 'text/csv;charset=utf-8;' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = (projectName || 'Lista_Cables') + '.csv';
    a.click();
}

// ── Render Box Diagrams ────────────────────────────────────────────────────────
function renderBoxDiagrams() {
    const container = document.getElementById('boxDiagramsRenderer');
    container.innerHTML = '';

    // Aggregate data grouped by Box Tag
    const boxes = {};

    // Local helper for terminal indexing
    const getTermIdx = (label, max) => {
        if (!label) return 0;
        const clean = label.toString().trim().toUpperCase();
        if (clean === 'PE' || clean === 'GND' || clean === 'SH' || clean === 'TERRA') return parseInt(max, 10) || 48;

        // Handle +/- Pairing pattern (e.g. 6+ -> 11, 6- -> 12)
        const match = clean.match(/^(\d+)([+-])$/);
        if (match) {
            const n = parseInt(match[1], 10);
            const sign = match[2];
            return sign === '+' ? (n * 2) - 1 : (n * 2);
        }

        const n = parseInt(clean, 10);
        return isNaN(n) ? 0 : n;
    };

    sheets.forEach((sheet) => {
        sheet.forEach((loop) => {
            if (!loop.instTag || loop.instTag.trim() === '') return;

            const category = loop.instCategory || 'STD';
            const tCount = category === 'STD' ? 2 : (category === '3W' ? 3 : (category === 'VALVE' ? 6 : 8));

            // Collect JB
            if (loop.jbEnabled && loop.jbTag) {
                const tag = loop.jbTag.trim().toUpperCase();
                const m = parseInt(loop.jbMaxTerms, 10) || 48;
                if (!boxes[tag]) boxes[tag] = { type: 'CAJA', module: loop.jbModule || '', max: m, terms: [] };
                boxes[tag].module = loop.jbModule || boxes[tag].module;
                if (m > boxes[tag].max) boxes[tag].max = m; // Group by highest capacity found

                const jh = loop.jbHilos || {};
                const ih = loop.instHilos || [];

                for (let i = 0; i < tCount; i++) {
                    const tName = (loop.jbTerms && loop.jbTerms[i]) || (i + 1).toString();
                    const tIdx = getTermIdx(tName, boxes[tag].max);

                    let hi = '', ho = '';
                    if (i === 0) { hi = jh.inPos || ih[0]; ho = jh.outPos || ih[0]; }
                    else if (i === 1) { hi = jh.inNeg || ih[1]; ho = jh.outNeg || ih[1]; }
                    else if (i === 2 && tCount > 2) { hi = jh.inSh || ih[2]; ho = jh.outSh || ih[2]; }
                    else { hi = ih[i] || ''; ho = ih[i] || ''; }

                    boxes[tag].terms.push({ val: tIdx, label: tName, loop: loop.instTag, hilosIn: hi, hilosOut: ho });
                }
                // Add PE terminal if not already included and specifically defined
                if (loop.jbTermSh && !boxes[tag].terms.some(t => t.label === loop.jbTermSh)) {
                    const tName = loop.jbTermSh;
                    boxes[tag].terms.push({
                        val: getTermIdx(tName, boxes[tag].max), label: tName, loop: loop.instTag,
                        hilosIn: jh.inSh || '', hilosOut: jh.outSh || ''
                    });
                }
            }

            // Collect Marsh
            if (loop.marshEnabled && loop.marshTag) {
                const tag = loop.marshTag.trim().toUpperCase();
                const m = parseInt(loop.marshMaxTerms, 10) || 48;
                if (!boxes[tag]) boxes[tag] = { type: 'MARSHALLING', module: loop.marshModule || '', max: m, terms: [] };
                boxes[tag].module = loop.marshModule || boxes[tag].module;
                if (m > boxes[tag].max) boxes[tag].max = m; // Group by highest capacity found

                const mh = loop.marshHilos || {};
                const ih = loop.instHilos || [];

                for (let i = 0; i < tCount; i++) {
                    const tName = (loop.marshTerms && loop.marshTerms[i]) || (i + 1).toString();
                    const tIdx = getTermIdx(tName, boxes[tag].max);

                    let hi = '', ho = '';
                    if (i === 0) { hi = mh.inPos || ih[0]; ho = mh.outPos || ih[0]; }
                    else if (i === 1) { hi = mh.inNeg || ih[1]; ho = mh.outNeg || ih[1]; }
                    else if (i === 2 && tCount > 2) { hi = mh.inSh || ih[2]; ho = mh.outSh || ih[2]; }
                    else { hi = ih[i] || ''; ho = ih[i] || ''; }

                    boxes[tag].terms.push({ val: tIdx, label: tName, loop: loop.instTag, hilosIn: hi, hilosOut: ho });
                }
                if (loop.marshTermInSh && !boxes[tag].terms.some(t => t.label === loop.marshTermInSh)) {
                    const tName = loop.marshTermInSh;
                    boxes[tag].terms.push({
                        val: getTermIdx(tName, boxes[tag].max), label: tName, loop: loop.instTag,
                        hilosIn: mh.inSh || '', hilosOut: mh.outSh || ''
                    });
                }
            }
        });
    });

    if (Object.keys(boxes).length === 0) {
        container.innerHTML = '<p>No hay cajas ni marshalling definidos en el proyecto actual.</p>';
        return;
    }

    // Sort boxes alphabetically
    const sortedKeys = Object.keys(boxes).sort();

    for (const tag of sortedKeys) {
        const data = boxes[tag];
        // Build panel
        const panel = document.createElement('div');
        panel.className = 'box-panel';
        panel.style.background = '#252526';
        panel.style.border = '1px solid #444';
        panel.style.padding = '20px';
        panel.style.borderRadius = '8px';

        let colsCount = Math.ceil((data.max || 48) / 24);
        if (colsCount < 1) colsCount = 1;

        // Final Box size calculation with 100mm margins on all sides
        const termH = 144; // 24 terminals * 6mm/term
        const estH = termH + 200; // 100mm top + 100mm bottom = 344mm total
        const estW = (colsCount * 120) + 200; // 120mm per rail + 100mm left + 100mm right
        const estD = 210; // Standard depth for wall-mounted JB

        let header = `
            <div style="border-bottom: 2px solid #007acc; padding-bottom: 10px; margin-bottom: 20px;">
                <h3 style="margin: 0; color: #4cc2ff; font-size: 20px;">${data.type}: ${tag}</h3>
                <div style="font-size: 14px; color: #aaa; margin-top: 5px;">
                    Bornero: <strong style="color: white;">${data.module || 'N/A'}</strong> | 
                    Bornas: <strong style="color: white;">${data.max}</strong>
                </div>
                <div style="font-size: 13px; color: #888; margin-top: 5px; font-family: monospace;">
                    [Dimensiones Físicas Estimadas: ${estW} x ${estH} x ${estD} mm (Ancho x Alto x Fondo)]
                </div>
            </div>
            <div class="box-grid" style="display: flex; gap: 100px; padding: 100px 100px 100px 100px; justify-content: flex-start;">
        `;

        // Sort used terminals by value - allow multiple loops per terminal
        const usedTerms = {};
        data.terms.forEach(t => {
            const k = t.val;
            if (!usedTerms[k]) usedTerms[k] = [];
            usedTerms[k].push(t);
        });

        // Generate columns
        for (let c = 0; c < colsCount; c++) {
            let colHTML = '<div style="display: flex; flex-direction: column; width: 140px; border: 1px solid #444; border-radius: 4px; overflow: hidden; background: #222;">';
            colHTML += `<div style="text-align: center; background: #333; padding: 4px; font-weight: bold; font-size: 12px; border-bottom: 1px solid #444; color: #fff;">Columna ${c + 1}</div>`;

            const startIdx = c * 24 + 1;
            const endIdx = Math.min((c + 1) * 24, data.max);

            for (let i = startIdx; i <= endIdx; i++) {
                const loopGroup = usedTerms[i] || [];
                const isUsed = loopGroup.length > 0;

                // Pairing pattern label: 1 is 1+, 2 is 1-, etc.
                const pairNum = Math.ceil(i / 2);
                const isNeg = i % 2 === 0;
                let defaultLabel = `${pairNum}${isNeg ? '-' : '+'}`;

                // If term is Max, it's usually ground (PE)
                if (i === (data.max || 48)) {
                    defaultLabel = 'PE';
                }

                // If isUsed has a label that is NOT just the numeric index, we use it. 
                // Otherwise we use the pairing label.
                let terminalLabel = defaultLabel;
                const customLoop = loopGroup.find(lg => lg.label && lg.label.toString() !== i.toString());
                if (customLoop) {
                    terminalLabel = customLoop.label;
                }

                const bg = isUsed ? '#007acc' : '#1e1e1e';
                const color = isUsed ? '#fff' : '#555';

                // Show multiple loop tags if applicable
                const loopTags = [...new Set(loopGroup.map(lg => lg.loop))].join(', ');
                const badge = isUsed ? `<span style="position: absolute; top: -8px; left: 5px; font-size: 7px; color: #aaa; pointer-events: none; white-space: nowrap;">${loopTags}</span>` : '';

                // Hilos inside box (from first loop found)
                let lText = '', rText = '';
                if (isUsed) {
                    const first = loopGroup[0];
                    if (first.hilosIn) lText = `<span style="position: absolute; left: 5px; font-size: 9px; color: #ffaa00; font-weight: bold;">${first.hilosIn}</span>`;
                    if (first.hilosOut) rText = `<span style="position: absolute; right: 5px; font-size: 9px; color: #ffaa00; font-weight: bold;">${first.hilosOut}</span>`;
                }

                colHTML += `
                    <div style="position: relative; height: 20px; border-bottom: 1px solid #333; display: flex; align-items: center; justify-content: center; background: ${bg}; color: ${color}; font-family: monospace; font-size: 12px;">
                        ${badge}
                        ${lText}
                        <span style="font-weight: bold; z-index: 2;">${terminalLabel}</span>
                        ${rText}
                    </div>
                `;
            }
            // Fill remainder if this column has less than 24 but is the last one with some size
            for (let i = endIdx + 1; i <= (c + 1) * 24; i++) {
                colHTML += `<div style="height: 20px; border-bottom: 1px solid #333; background: #1a1a1a;"></div>`;
            }

            colHTML += `</div>`;
            header += colHTML;
        }

        header += `</div>`;
        panel.innerHTML = header;
        container.appendChild(panel);
    }
}


